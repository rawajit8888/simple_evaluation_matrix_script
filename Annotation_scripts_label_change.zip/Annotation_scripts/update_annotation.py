import os
import json
import requests
import pandas as pd
from dotenv import load_dotenv

# ---------------- LOAD ENV ----------------
load_dotenv()

BASE_URL = os.getenv("LABEL_STUDIO_URL").rstrip("/")
API_KEY = os.getenv("LABEL_STUDIO_API_KEY")
CSV_PATH = os.getenv("CSV_PATH")
DRY_RUN = os.getenv("DRY_RUN", "false").lower() == "true"

HEADERS = {
    "Authorization": f"Token {API_KEY}",
    "Content-Type": "application/json"
}

# ---------------- HTTP HELPERS ----------------
def ls_get(url):
    r = requests.get(url, headers=HEADERS)
    r.raise_for_status()
    return r.json()

def ls_patch(url, payload):
    if DRY_RUN:
        print(f"[DRY-RUN] PATCH {url}")
        return
    r = requests.patch(url, headers=HEADERS, json=payload)
    r.raise_for_status()

def ls_delete(url):
    if DRY_RUN:
        print(f"[DRY-RUN] DELETE {url}")
        return
    r = requests.delete(url, headers=HEADERS)
    r.raise_for_status()

def ls_post(url, payload):
    if DRY_RUN:
        print(f"[DRY-RUN] POST {url}")
        print(json.dumps(payload, indent=2))
        return
    r = requests.post(url, headers=HEADERS, json=payload)
    r.raise_for_status()

# ---------------- MAIN ----------------
def main():
    df = pd.read_csv(CSV_PATH)

    for _, row in df.iterrows():
        task_id = str(row["ID"]).strip()
        master = row["MasterDepartment"]
        dept = row["Department"]
        query = row["QueryType"]

        print(f"\nProcessing TASK ID = {task_id}")

        # 1 Get FULL task
        try:
            task = ls_get(f"{BASE_URL}/api/tasks/{task_id}/")
        except Exception as e:
            print(f"   Task not found: {e}")
            continue

        # 2 Update task.data (SAFE MERGE)
        data = task["data"].copy()
        data["MasterDepartment"] = master
        data["Department"] = dept
        data["QueryType"] = query

        ls_patch(f"{BASE_URL}/api/tasks/{task_id}/", {"data": data})

        # 3 Handle annotation
        if not task.get("annotations"):
            print("  ⚠ No annotation found")
            continue

        ann = task["annotations"][0]
        ann_id = ann["id"]

        classification = None
        sentiment = None

        for r in ann["result"]:
            if r["from_name"] == "classification":
                classification = r
            if r["from_name"] == "sentiment":
                sentiment = r

        if not classification:
            print("  ⚠ No classification block")
            continue

        sub_query = classification["value"]["taxonomy"][0][3]

        # 4 DELETE old annotation
        ls_delete(f"{BASE_URL}/api/annotations/{ann_id}/")

        # 5 CREATE new annotation
        new_result = [{
            "from_name": "classification",
            "to_name": "text",
            "type": "taxonomy",
            "value": {
                "taxonomy": [[
                    master,
                    dept,
                    query,
                    sub_query
                ]]
            }
        }]

        if sentiment:
            new_result.append(sentiment)

        payload = {
            "completed_by": ann["completed_by"]["id"],
            "result": new_result
        }

        ls_post(f"{BASE_URL}/api/tasks/{task_id}/annotations/", payload)

        print("   UPDATED (correct task & annotation)")

    print("\n ALL DONE")

# ---------------- RUN ----------------
if __name__ == "__main__":
    main()
