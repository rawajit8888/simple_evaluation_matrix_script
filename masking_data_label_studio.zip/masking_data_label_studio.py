import re
import requests
import torch
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
from presidio_analyzer import Pattern, PatternRecognizer, AnalyzerEngine, RecognizerRegistry, EntityRecognizer, RecognizerResult
import json
import os

# =========================
# GPU setup
# =========================
device = 0 if torch.cuda.is_available() else -1
print(f"Using device: {'GPU' if device >= 0 else 'CPU'}")

# =========================
# Load IndicNER for PERSON
# =========================
model_name = r"E:\Projects\masking_label_studio_data\indi_ner_model"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)
ner_pipeline = pipeline(
    "ner",
    model=model,
    tokenizer=tokenizer,
    aggregation_strategy="simple",
    device=device
)

class IndicNERRecognizer(EntityRecognizer):
    def __init__(self, ner_pipeline, supported_entities=None, name="IndicNERRecognizer"):
        self.ner_pipeline = ner_pipeline
        supported_entities = supported_entities or ["PERSON"]
        super().__init__(supported_entities=supported_entities, name=name)

    def analyze(self, text, entities, nlp_artifacts=None):
        results = []
        predictions = self.ner_pipeline(text)
        for p in predictions:
            if p["entity_group"] == "PER" and "PERSON" in entities:
                results.append(
                    RecognizerResult(
                        entity_type="PERSON",
                        start=p["start"],
                        end=p["end"],
                        score=p["score"]
                    )
                )
        return results


# =========================
# Regex Patterns from Config
# =========================
CONFIG_PATH = r"E:\Projects\masking_label_studio_data\config.json"
patterns = []
if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        config = json.load(f)
    patterns = [(item["name"], item["regex"]) for item in config.get("patterns", [])]
else:
    print(f" Config file not found at {CONFIG_PATH}")

# =========================
# Register recognizers
# =========================
registry = RecognizerRegistry()
registry.load_predefined_recognizers()  # PHONE_NUMBER, EMAIL_ADDRESS included

for name, regex in patterns:
    pattern = Pattern(name=f"{name} pattern", regex=regex, score=1.0)
    recognizer = PatternRecognizer(supported_entity=name, patterns=[pattern])
    registry.add_recognizer(recognizer)

registry.add_recognizer(IndicNERRecognizer(ner_pipeline))
analyzer = AnalyzerEngine(registry=registry)

# =========================
# Masking Helpers
# =========================
def partial_mask(value, unmasked_digits=4):
    """Mask all but last few digits."""
    if len(value) <= unmasked_digits:
        return "X" * len(value)
    return "X" * (len(value) - unmasked_digits) + value[-unmasked_digits:]

def mask_text(text):
    entities_to_mask = [e[0] for e in patterns] + ["PERSON", "PHONE_NUMBER", "EMAIL_ADDRESS"]
    results = analyzer.analyze(text=text, entities=entities_to_mask, language='en')

    # Sort in reverse order to avoid offset issues
    results = sorted(results, key=lambda x: x.start, reverse=True)
    masked_text = text

    email_count = 0
    name_count = 0

    for r in results:
        start, end = r.start, r.end
        original = masked_text[start:end]

        # Skip masking if starts with www.
        if original.strip().lower().startswith("www."):
            continue

        if r.entity_type == "PERSON":
            start = r.start
            while start > 0 and text[start - 1].isalpha():
                start -= 1
            end = r.end
            while end < len(text) and text[end].isalpha():
                end += 1

            full_name = text[start:end]
            name_count += 1
            masked_value = f"[NAME {name_count}]"

            masked_text = masked_text[:start] + masked_value + " " + masked_text[end:]

        elif r.entity_type == "EMAIL_ADDRESS":
            email_count += 1
            replacement = f"[EMAIL {email_count}]"
            masked_text = masked_text[:start] + replacement + masked_text[end:]

        elif r.entity_type == "URL":
            replacement = "[URL]"
            masked_text = masked_text[:start] + replacement + masked_text[end:]

        elif r.entity_type in [
            "DP_ACCOUNT", "DP_ID", "TRADING_ID", "PAN",
            "DP_ACCOUNT_CDSL", "BANK_ACC", "AADHAR", "PHONE_NUMBER", "IFSC"
        ]:
            replacement = partial_mask(original)
            masked_text = masked_text[:start] + replacement + masked_text[end:]

    # === Post-process: merge consecutive [NAME X] masks ===
    masked_text = re.sub(r'\[NAME \d+\](\s*\[NAME \d+\])+', lambda m: m.group(0).split()[0], masked_text)

    return masked_text


# =========================
# Label Studio API
# =========================
API_TOKEN = "5eaa022154752a5822f2eb552011143958a753a0"
BASE_URL = "http://localhost:8080/api"

def get_tasks(project_id, page=1):
    """
    Fetch tasks from Label Studio API for a specific project and page.
    """
    url = f"{BASE_URL}/tasks/?page={page}&project={project_id}&fields=task_only"
    headers = {
        "accept": "application/json",
        "Authorization": f"Token {API_TOKEN}"
    }

    try:
        response = requests.get(url, headers=headers, verify=False)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"❌ Error fetching page {page}: {e}")
        return []

    data = response.json()
    if isinstance(data, dict):
        return data.get("results", []) or data.get("tasks", [])
    return data

def update_task(task):
    task_id = task["id"]
    original_html = task.get("data", {}).get("html", "")
    masked_html = mask_text(original_html)
    task["data"]["html"] = masked_html

    url = f"{BASE_URL}/tasks/{task_id}/"
    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Token {API_TOKEN}"
    }
    response = requests.patch(url, headers=headers, json={
        "data": task["data"],
        "project": task["project"]
    })

    if response.status_code in [200, 201]:
        print(f"✅ Task {task_id} updated successfully.")
    else:
        print(f"❌ Failed to update task {task_id}: {response.status_code} - {response.text}")

def process_project_tasks(project_id):
    """
    Iterates over pages automatically until no more tasks are found.
    """
    page = 1
    total_processed = 0

    while True:
        tasks = get_tasks(project_id, page=page)
        if not tasks:
            print(f"✅ No more tasks found. Total processed: {total_processed}")
            break

        print(f"📄 Processing page {page} with {len(tasks)} tasks...")
        for task in tasks:
            update_task(task)
            total_processed += 1

        page += 1


# =========================
# Run
# =========================
if __name__ == "__main__":
    PROJECT_ID = 7
    process_project_tasks(PROJECT_ID)
