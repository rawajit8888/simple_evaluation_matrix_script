import os
import pathlib
import re
import numpy as np
import pandas as pd
from tqdm import tqdm
import time
from datetime import datetime, timedelta

import label_studio_sdk
import logging

# SubQueryNNModel is now defined in this file (below) - no separate import needed

from typing import List, Dict, Optional
from label_studio_ml.model import LabelStudioMLBase
from label_studio_ml.response import ModelResponse

import torch
import torch.optim as optim
import torch.nn as nn

from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
from torch.utils.data import RandomSampler
from torch.utils.data import SequentialSampler

from keras.utils import pad_sequences
from transformers import pipeline, Pipeline, BertModel
from transformers import AdamW
from itertools import groupby
from transformers import AutoModelForTokenClassification, TrainingArguments, Trainer, AutoTokenizer, AdamW
from transformers import DataCollatorForTokenClassification
from datasets import Dataset, ClassLabel, Value, Sequence, Features
from functools import partial
from dataprocessing.processlabels import ProcessLabels
from multitask_nn_model import MultiTaskNNModel
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
import pickle

logger = logging.getLogger(__name__)


# ========== SubQueryNNModel Class (Moved from separate file) ==========

class SubQueryNNModel(nn.Module):
    """
    Sub-query classification model with bundled label encoder.
    Uses same BERT backbone as MultiTask model for consistency.
    
    NOTE: This class is now part of multi_task_model.py (no separate file needed)
    """
    
    def __init__(self, modelname, num_labels):
        super(SubQueryNNModel, self).__init__()
        
        # Use SAME backbone type as MultiTaskNNModel
        self.bert = BertModel.from_pretrained(modelname)
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(
            self.bert.config.hidden_size,
            num_labels
        )
        
        # Store encoder (will be set during training)
        self.encoder = None
        
    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )
        
        pooled_output = outputs[1]  # CLS pooled output
        pooled_output = self.dropout(pooled_output)
        
        logits = self.classifier(pooled_output)
        return logits
    
    def set_encoder(self, encoder):
        """Set label encoder before saving"""
        self.encoder = encoder
        logger.info("✅ Encoder attached to SubQuery model")
    
    def save(self, directorypath):
        """Save model with bundled encoder"""
        try:
            os.makedirs(directorypath, exist_ok=True)
            
            # Save BERT backbone
            logger.info(f"💾 Saving SubQuery BERT to {directorypath}")
            self.bert.save_pretrained(directorypath)
            
            # Save classifier head
            classifier_path = os.path.join(directorypath, "subquery_classifier.pth")
            logger.info(f"💾 Saving classifier head to {classifier_path}")
            torch.save(
                self.classifier.state_dict(),
                classifier_path
            )
            
            # Save bundled encoder
            encoder_path = os.path.join(directorypath, 'subquery_encoder.pkl')
            logger.info(f"💾 Saving subquery encoder to {encoder_path}")
            with open(encoder_path, 'wb') as f:
                pickle.dump(self.encoder, f)
            
            logger.info("✅ SubQuery model and encoder saved successfully")
            
        except Exception as e:
            logger.error(f"❌ Error saving SubQuery model: {e}")
            raise
    
    def load(self, directorypath):
        """Load model with bundled encoder"""
        try:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            
            # Reload BERT
            logger.info(f"📂 Loading SubQuery BERT from {directorypath}")
            self.bert = BertModel.from_pretrained(directorypath)
            
            # Reload classifier head
            classifier_path = os.path.join(directorypath, "subquery_classifier.pth")
            logger.info(f"📂 Loading classifier head from {classifier_path}")
            self.classifier.load_state_dict(
                torch.load(
                    classifier_path,
                    map_location=device
                )
            )
            
            # Load bundled encoder
            encoder_path = os.path.join(directorypath, 'subquery_encoder.pkl')
            if os.path.exists(encoder_path):
                logger.info(f"📂 Loading bundled subquery encoder from {encoder_path}")
                with open(encoder_path, 'rb') as f:
                    self.encoder = pickle.load(f)
                logger.info("✅ SubQuery model and encoder loaded successfully")
            else:
                logger.warning("⚠️  No bundled encoder found for SubQuery - using external encoder")
            
            self.eval()
            
        except Exception as e:
            logger.error(f"❌ Error loading SubQuery model: {e}")
            raise
    
    def get_encoder(self):
        """Safely retrieve encoder"""
        if self.encoder is None:
            raise ValueError("SubQuery encoder is None")
        return self.encoder


# ========== 3-LEVEL HIERARCHICAL MODELS ==========

class Level1Model(nn.Module):
    """
    Level 1: Email → MasterDepartment
    """
    
    def __init__(self, modelname, num_labels):
        super(Level1Model, self).__init__()
        
        self.bert = BertModel.from_pretrained(modelname)
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(
            self.bert.config.hidden_size,
            num_labels
        )
        
        self.encoder = None
        
    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )
        
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)
        
        logits = self.classifier(pooled_output)
        return logits
    
    def set_encoder(self, encoder):
        """Set label encoder before saving"""
        self.encoder = encoder
        logger.info("✅ Encoder attached to Level 1 (MasterDepartment) model")
    
    def save(self, directorypath):
        """Save model with bundled encoder"""
        try:
            os.makedirs(directorypath, exist_ok=True)
            
            logger.info(f"💾 Saving Level 1 BERT to {directorypath}")
            self.bert.save_pretrained(directorypath)
            
            classifier_path = os.path.join(directorypath, "level1_classifier.pth")
            logger.info(f"💾 Saving Level 1 classifier head to {classifier_path}")
            torch.save(self.classifier.state_dict(), classifier_path)
            
            encoder_path = os.path.join(directorypath, 'level1_encoder.pkl')
            logger.info(f"💾 Saving Level 1 encoder to {encoder_path}")
            with open(encoder_path, 'wb') as f:
                pickle.dump(self.encoder, f)
            
            logger.info("✅ Level 1 model and encoder saved successfully")
            
        except Exception as e:
            logger.error(f"❌ Error saving Level 1 model: {e}")
            raise
    
    def load(self, directorypath):
        """Load model with bundled encoder"""
        try:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            
            logger.info(f"📂 Loading Level 1 BERT from {directorypath}")
            self.bert = BertModel.from_pretrained(directorypath)
            
            classifier_path = os.path.join(directorypath, "level1_classifier.pth")
            logger.info(f"📂 Loading Level 1 classifier head from {classifier_path}")
            self.classifier.load_state_dict(
                torch.load(classifier_path, map_location=device)
            )
            
            encoder_path = os.path.join(directorypath, 'level1_encoder.pkl')
            if os.path.exists(encoder_path):
                logger.info(f"📂 Loading bundled Level 1 encoder from {encoder_path}")
                with open(encoder_path, 'rb') as f:
                    self.encoder = pickle.load(f)
                logger.info("✅ Level 1 model and encoder loaded successfully")
            else:
                logger.warning("⚠️  No bundled encoder found for Level 1")
            
            self.eval()
            
        except Exception as e:
            logger.error(f"❌ Error loading Level 1 model: {e}")
            raise
    
    def get_encoder(self):
        """Safely retrieve encoder"""
        if self.encoder is None:
            raise ValueError("Level 1 encoder is None")
        return self.encoder


class Level2Model(nn.Module):
    """
    Level 2: Email + MasterDepartment → Department
    """
    
    def __init__(self, modelname, num_labels):
        super(Level2Model, self).__init__()
        
        self.bert = BertModel.from_pretrained(modelname)
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(
            self.bert.config.hidden_size,
            num_labels
        )
        
        self.encoder = None
        
    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )
        
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)
        
        logits = self.classifier(pooled_output)
        return logits
    
    def set_encoder(self, encoder):
        """Set label encoder before saving"""
        self.encoder = encoder
        logger.info("✅ Encoder attached to Level 2 (Department) model")
    
    def save(self, directorypath):
        """Save model with bundled encoder"""
        try:
            os.makedirs(directorypath, exist_ok=True)
            
            logger.info(f"💾 Saving Level 2 BERT to {directorypath}")
            self.bert.save_pretrained(directorypath)
            
            classifier_path = os.path.join(directorypath, "level2_classifier.pth")
            logger.info(f"💾 Saving Level 2 classifier head to {classifier_path}")
            torch.save(self.classifier.state_dict(), classifier_path)
            
            encoder_path = os.path.join(directorypath, 'level2_encoder.pkl')
            logger.info(f"💾 Saving Level 2 encoder to {encoder_path}")
            with open(encoder_path, 'wb') as f:
                pickle.dump(self.encoder, f)
            
            logger.info("✅ Level 2 model and encoder saved successfully")
            
        except Exception as e:
            logger.error(f"❌ Error saving Level 2 model: {e}")
            raise
    
    def load(self, directorypath):
        """Load model with bundled encoder"""
        try:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            
            logger.info(f"📂 Loading Level 2 BERT from {directorypath}")
            self.bert = BertModel.from_pretrained(directorypath)
            
            classifier_path = os.path.join(directorypath, "level2_classifier.pth")
            logger.info(f"📂 Loading Level 2 classifier head from {classifier_path}")
            self.classifier.load_state_dict(
                torch.load(classifier_path, map_location=device)
            )
            
            encoder_path = os.path.join(directorypath, 'level2_encoder.pkl')
            if os.path.exists(encoder_path):
                logger.info(f"📂 Loading bundled Level 2 encoder from {encoder_path}")
                with open(encoder_path, 'rb') as f:
                    self.encoder = pickle.load(f)
                logger.info("✅ Level 2 model and encoder loaded successfully")
            else:
                logger.warning("⚠️  No bundled encoder found for Level 2")
            
            self.eval()
            
        except Exception as e:
            logger.error(f"❌ Error loading Level 2 model: {e}")
            raise
    
    def get_encoder(self):
        """Safely retrieve encoder"""
        if self.encoder is None:
            raise ValueError("Level 2 encoder is None")
        return self.encoder


class Level3Model(nn.Module):
    """
    Level 3: Email + MasterDepartment + Department → QueryType
    """
    
    def __init__(self, modelname, num_labels):
        super(Level3Model, self).__init__()
        
        self.bert = BertModel.from_pretrained(modelname)
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(
            self.bert.config.hidden_size,
            num_labels
        )
        
        self.encoder = None
        
    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )
        
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)
        
        logits = self.classifier(pooled_output)
        return logits
    
    def set_encoder(self, encoder):
        """Set label encoder before saving"""
        self.encoder = encoder
        logger.info("✅ Encoder attached to Level 3 (QueryType) model")
    
    def save(self, directorypath):
        """Save model with bundled encoder"""
        try:
            os.makedirs(directorypath, exist_ok=True)
            
            logger.info(f"💾 Saving Level 3 BERT to {directorypath}")
            self.bert.save_pretrained(directorypath)
            
            classifier_path = os.path.join(directorypath, "level3_classifier.pth")
            logger.info(f"💾 Saving Level 3 classifier head to {classifier_path}")
            torch.save(self.classifier.state_dict(), classifier_path)
            
            encoder_path = os.path.join(directorypath, 'level3_encoder.pkl')
            logger.info(f"💾 Saving Level 3 encoder to {encoder_path}")
            with open(encoder_path, 'wb') as f:
                pickle.dump(self.encoder, f)
            
            logger.info("✅ Level 3 model and encoder saved successfully")
            
        except Exception as e:
            logger.error(f"❌ Error saving Level 3 model: {e}")
            raise
    
    def load(self, directorypath):
        """Load model with bundled encoder"""
        try:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            
            logger.info(f"📂 Loading Level 3 BERT from {directorypath}")
            self.bert = BertModel.from_pretrained(directorypath)
            
            classifier_path = os.path.join(directorypath, "level3_classifier.pth")
            logger.info(f"📂 Loading Level 3 classifier head from {classifier_path}")
            self.classifier.load_state_dict(
                torch.load(classifier_path, map_location=device)
            )
            
            encoder_path = os.path.join(directorypath, 'level3_encoder.pkl')
            if os.path.exists(encoder_path):
                logger.info(f"📂 Loading bundled Level 3 encoder from {encoder_path}")
                with open(encoder_path, 'rb') as f:
                    self.encoder = pickle.load(f)
                logger.info("✅ Level 3 model and encoder loaded successfully")
            else:
                logger.warning("⚠️  No bundled encoder found for Level 3")
            
            self.eval()
            
        except Exception as e:
            logger.error(f"❌ Error loading Level 3 model: {e}")
            raise
    
    def get_encoder(self):
        """Safely retrieve encoder"""
        if self.encoder is None:
            raise ValueError("Level 3 encoder is None")
        return self.encoder


# ========== TrainingLogger Class ==========

class TrainingLogger:
    """Enhanced training logger with time estimates"""
    
    def __init__(self, logger, total_epochs, total_batches):
        self.logger = logger
        self.total_epochs = total_epochs
        self.total_batches = total_batches
        self.start_time = None
        self.epoch_times = []
        
    def start_training(self, model_name="Model"):
        """Mark training start"""
        self.start_time = time.time()
        self.logger.info("=" * 80)
        self.logger.info(f"🚀 {model_name} TRAINING STARTED")
        self.logger.info(f"📊 Total Epochs: {self.total_epochs}")
        self.logger.info(f"📦 Total Batches per Epoch: {self.total_batches}")
        self.logger.info(f"⏰ Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("=" * 80)
        
    def start_epoch(self, epoch):
        """Mark epoch start"""
        self.epoch_start = time.time()
        self.logger.info("")
        self.logger.info(f"📍 EPOCH {epoch + 1}/{self.total_epochs}")
        self.logger.info("-" * 80)
        
    def log_batch(self, epoch, batch_idx, loss, **extra_losses):
        """Log batch progress"""
        if batch_idx % 10 == 0:  # Log every 10 batches
            progress = (batch_idx / self.total_batches) * 100
            loss_str = f"Loss: {loss:.4f}"
            
            # Add extra losses if provided
            for name, value in extra_losses.items():
                loss_str += f" | {name}: {value:.4f}"
            
            self.logger.info(
                f"  Batch {batch_idx}/{self.total_batches} ({progress:.1f}%) | {loss_str}"
            )
    
    def end_epoch(self, epoch, avg_loss):
        """Mark epoch end and estimate remaining time"""
        epoch_time = time.time() - self.epoch_start
        self.epoch_times.append(epoch_time)
        
        # Calculate ETA
        avg_epoch_time = np.mean(self.epoch_times)
        remaining_epochs = self.total_epochs - (epoch + 1)
        eta_seconds = avg_epoch_time * remaining_epochs
        eta = timedelta(seconds=int(eta_seconds))
        
        self.logger.info("-" * 80)
        self.logger.info(f"✅ Epoch {epoch + 1} Complete")
        self.logger.info(f"⏱️  Epoch Time: {timedelta(seconds=int(epoch_time))}")
        self.logger.info(f"📉 Average Loss: {avg_loss:.4f}")
        self.logger.info(f"⏳ Estimated Time Remaining: {eta}")
        
    def end_training(self):
        """Mark training end"""
        total_time = time.time() - self.start_time
        self.logger.info("")
        self.logger.info("=" * 80)
        self.logger.info("🎉 TRAINING COMPLETED")
        self.logger.info(f"⏱️  Total Training Time: {timedelta(seconds=int(total_time))}")
        self.logger.info(f"⏰ End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("=" * 80)


class MultiTaskBertModel:
    """
    Hierarchical BERT Classification Model
    - Level 1: Email → QueryType + Sentiment
    - Level 2: Email + QueryType → SubQueryType
    
    Features:
    - Bundled encoders with models (risk-free deployment)
    - Comprehensive logging with time estimates
    - Automatic inference routing
    """

    LABEL_STUDIO_HOST = os.getenv('LABEL_STUDIO_HOST', 'http://localhost:8080')
    LABEL_STUDIO_API_KEY = os.getenv('LABEL_STUDIO_API_KEY', '830eb6d65978e36293a63635717da95bbbcb7a9d')
    START_TRAINING_EACH_N_UPDATES = int(os.getenv('START_TRAINING_EACH_N_UPDATES', 10))
    LEARNING_RATE = float(os.getenv('LEARNING_RATE', 1e-3))
    NUM_TRAIN_EPOCHS = int(os.getenv('NUM_TRAIN_EPOCHS', 100))
    WEIGHT_DECAY = float(os.getenv('WEIGHT_DECAY', 0.01))

    def __init__(self, config, logger, label_interface=None, parsed_label_config=None):
        self.config = config
        self.logger = logger
        self.label_interface = label_interface
        self.parsed_label_config = parsed_label_config
        
        # Initialize label processors
        self.processed_label_encoders = ProcessLabels(
            self.parsed_label_config,
            pathlib.Path(self.config['MODEL_DIR'])
        )
        
        # Models will be loaded on reload_model()
        self.model = None
        self.subquery_model = None
        self.tokenizer = None

    def save_metrics_to_sqlite(
        self,
        class_accuracy,
        class_f1_weighted,
        sent_accuracy,
        sent_f1_weighted,
        train_size,
        test_size
    ):
        """Save training metrics to SQLite database"""
        import sqlite3
        from datetime import datetime

        base_dir = os.path.dirname(self.finedtunnedmodelpath)
        eval_dir = os.path.join(base_dir, "evaluation")
        os.makedirs(eval_dir, exist_ok=True)

        db_path = os.path.join(eval_dir, "evaluation.db")
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS run_info (
            run_id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT,
            train_size INTEGER,
            test_size INTEGER
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS evaluation_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id INTEGER,
            task TEXT,
            metric TEXT,
            value REAL
        )
        """)

        cur.execute("""
        INSERT INTO run_info (created_at, train_size, test_size)
        VALUES (?, ?, ?)
        """, (datetime.now().isoformat(), train_size, test_size))

        run_id = cur.lastrowid

        metrics = [
            ("classification", "accuracy", class_accuracy),
            ("classification", "f1_weighted", class_f1_weighted),
            ("sentiment", "accuracy", sent_accuracy),
            ("sentiment", "f1_weighted", sent_f1_weighted),
        ]

        cur.executemany("""
        INSERT INTO evaluation_metrics (run_id, task, metric, value)
        VALUES (?, ?, ?, ?)
        """, [(run_id, *m) for m in metrics])

        conn.commit()
        conn.close()
        
        self.logger.info(f"💾 Metrics saved to database (run_id: {run_id})")
        return run_id

    def save_full_classification_report_to_sqlite(
        self,
        run_id,
        task_name,
        y_true,
        y_pred
    ):
        """Save detailed classification report to SQLite"""
        import sqlite3, re
        from sklearn.metrics import classification_report

        def clean(name):
            return re.sub(r'[^a-zA-Z0-9_]+', '_', name).lower()

        base_dir = os.path.dirname(self.finedtunnedmodelpath)
        db_path = os.path.join(base_dir, "evaluation", "evaluation.db")

        report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)

        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        cur.execute("""
        INSERT INTO evaluation_metrics (run_id, task, metric, value)
        VALUES (?, ?, ?, ?)
        """, (run_id, task_name, "accuracy_overall", float(report["accuracy"])))

        for avg in ["macro avg", "weighted avg"]:
            for m in ["precision", "recall", "f1-score"]:
                cur.execute("""
                INSERT INTO evaluation_metrics (run_id, task, metric, value)
                VALUES (?, ?, ?, ?)
                """, (run_id, task_name, clean(f"{avg}_{m}"), float(report[avg][m])))

        for label, values in report.items():
            if label in ["accuracy", "macro avg", "weighted avg"]:
                continue
            for m in ["precision", "recall", "f1-score", "support"]:
                cur.execute("""
                INSERT INTO evaluation_metrics (run_id, task, metric, value)
                VALUES (?, ?, ?, ?)
                """, (run_id, task_name, clean(f"{label}_{m}"), float(values.get(m, 0))))

        conn.commit()
        conn.close()

    def get_latest_metrics_from_db(self):
        """Retrieve latest evaluation metrics from database"""
        import sqlite3

        base_dir = os.path.dirname(self.finedtunnedmodelpath)
        db_path = os.path.join(base_dir, "evaluation", "evaluation.db")

        if not os.path.exists(db_path):
            return {"error": "evaluation.db not found"}

        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        cur.execute("SELECT * FROM run_info ORDER BY run_id DESC LIMIT 1")
        run = cur.fetchone()

        cur.execute("""
        SELECT task, metric, value
        FROM evaluation_metrics
        WHERE run_id = ?
        """, (run["run_id"],))

        metrics = [dict(r) for r in cur.fetchall()]
        conn.close()

        return {"run_info": dict(run), "metrics": metrics}

    def reload_model(self):
        """
        Load or initialize models with bundled encoders.
        Automatically handles both Level 1 (QueryType) and Level 2 (SubQueryType) models.
        """
        self.logger.info("🔄 Reloading models...")
        
        self.model = None
        self.subquery_model = None
        
        # Get label sizes
        classification_label_length = len(
            self.processed_label_encoders.labels["classification"]["encoder"].classes_
        ) if self.processed_label_encoders.labels["classification"]["encoder"] is not None else 1000
        
        sentiment_label_length = len(
            self.processed_label_encoders.labels["sentiment"]["encoder"].classes_
        ) if self.processed_label_encoders.labels["sentiment"]["encoder"] is not None else 3

        # ========== LEVEL 1: Multi-Task Model (QueryType + Sentiment) ==========
        try:
            self.chk_path = str(pathlib.Path(self.config['MODEL_DIR']) / self.config['FINETUNED_MODEL_NAME'])
            self.finedtunnedmodelpath = f'.\\{self.chk_path}'

            self.logger.info(f"📂 Loading Level 1 model from {self.chk_path}")
            self.model = MultiTaskNNModel(
                self.finedtunnedmodelpath,
                classification_label_length,
                sentiment_label_length
            )
            self.model.LoadModel(self.finedtunnedmodelpath)
            self.tokenizer = AutoTokenizer.from_pretrained(self.finedtunnedmodelpath)
            self.logger.info("✅ Level 1 model loaded successfully")

        except Exception as e:
            self.logger.info(f"⚠️  Finetuned model not found: {e}")
            self.logger.info("📂 Loading baseline model instead")
            
            self.chk_path = str(pathlib.Path(self.config['MODEL_DIR']) / self.config['BASELINE_MODEL_NAME'])
            self.finedtunnedmodelpath = f'.\\{self.chk_path}'
            
            self.model = MultiTaskNNModel(
                self.finedtunnedmodelpath,
                classification_label_length,
                sentiment_label_length
            )
            self.tokenizer = AutoTokenizer.from_pretrained(self.finedtunnedmodelpath)
            self.finedtunnedmodelpath = str(pathlib.Path(self.config['MODEL_DIR']) / self.config['FINETUNED_MODEL_NAME'])
            self.logger.info("✅ Baseline model loaded")

        # ========== LEVEL 2: SubQuery Model ==========
        subquery_path = str(pathlib.Path(self.config['MODEL_DIR']) / 'subquery_model')
        
        if os.path.exists(subquery_path):
            try:
                subquery_encoder = self.processed_label_encoders.labels["subquery"]["encoder"]
                subquery_label_length = len(subquery_encoder.classes_) if subquery_encoder is not None else 100

                self.logger.info(f"📂 Loading Level 2 SubQuery model from {subquery_path}")
                self.subquery_model = SubQueryNNModel(
                    subquery_path,
                    subquery_label_length
                )
                self.subquery_model.load(subquery_path)
                self.logger.info("✅ Level 2 SubQuery model loaded successfully")
                
            except Exception as e:
                self.logger.warning(f"⚠️  Could not load SubQuery model: {e}")
                self.subquery_model = None
        else:
            self.logger.info("ℹ️  No SubQuery model found - Level 2 predictions disabled")
            self.subquery_model = None
        
        self.logger.info("🎯 Model reload complete")

    def fit(self, event, data, tasks, **kwargs):
        """
        Train both Level 1 (QueryType + Sentiment) and Level 2 (SubQueryType) models
        with comprehensive logging and time estimates.
        """
        if event not in ('ANNOTATION_CREATED', 'ANNOTATION_UPDATED', 'START_TRAINING'):
            self.logger.info(f"Skip training: event {event} is not supported")
            return

        self.logger.info("=" * 80)
        self.logger.info("📚 DATA PREPARATION STARTED")
        self.logger.info("=" * 80)

        ds_raw = []

        def getClassificationAttrName(attrs):
            return attrs == 'classification'

        def getSentimentAttrName(attrs):
            return attrs == 'sentiment'

        from_name_classification, to_name_classification, value_classification = \
            self.label_interface.get_first_tag_occurence('Taxonomy', 'HyperText', getClassificationAttrName)
        from_name_sentiment, to_name_sentiment, value_sentiment = \
            self.label_interface.get_first_tag_occurence('Taxonomy', 'HyperText', getSentimentAttrName)

        tokenizer = self.tokenizer

        self.logger.info(f"📊 Processing {len(tasks)} tasks...")
        
        for task in tasks:
            # SubQueryType comes from Label Studio data
            subquery_type = task['data'].get('SubQueryType', 'Unknown')
            for annotation in task['annotations']:
                if not annotation.get('result'):
                    continue

                sentiment_label = [r['value']['taxonomy'][0][0] for r in annotation['result']
                                   if r["from_name"] == "sentiment"][0]
                classification_label = " > ".join(
                    [r['value']['taxonomy'][0] for r in annotation['result'] if r["from_name"] == "classification"][0]
                )

                match = re.search(r"pre[^>]*>\s*(.*?)\s*</pre>", value_classification, re.DOTALL)
                value_classification_clean = match.group(1)[1:] if match else value_classification

                text = self.preload_task_data(task, task['data'][value_classification_clean])

                sentiment = self.processed_label_encoders['sentiment'].transform([sentiment_label])[0]
                classification = self.processed_label_encoders['classification'].transform([classification_label])[0]

                # include SubQueryType
                ds_raw.append([
                    text,
                    classification_label,
                    sentiment_label,
                    classification,
                    sentiment,
                    subquery_type
                ])

        # Build dataframe
        df = pd.DataFrame(
            ds_raw,
            columns=["text", "classification_label", "sentiment_label",
                     "classification", "sentiment", "SubQueryType"]
        )

        self.logger.info(f"✅ Processed {len(df)} samples")
        self.reload_model()

        # ======================================================
        # LEVEL-2 INPUT (GROUND TRUTH QUERYTYPE ONLY)
        # ======================================================
        df["subquery_input_text"] = df.apply(
            lambda r: f"QueryType: {r['classification_label']} Email: {r['text']}",
            axis=1
        )

        # ---- Stratified 80/20 train/test split by SubQueryType ----
        self.logger.info("📊 Performing stratified train/test split...")
        df = df.sample(frac=1.0, random_state=42).reset_index(drop=True)
        df["SubQueryType"] = df["SubQueryType"].fillna("Unknown")

        train_indices = []
        test_indices = []

        rng = np.random.default_rng(42)

        for subq, group in df.groupby("SubQueryType"):
            idx = group.index.to_list()
            rng.shuffle(idx)
            n = len(idx)

            if n < 2:
                # If only 1 sample of this SubQueryType, keep it in train
                train_indices.extend(idx)
                continue

            n_train = int(np.floor(0.8 * n))
            if n_train == 0:
                n_train = 1

            train_indices.extend(idx[:n_train])
            test_indices.extend(idx[n_train:])

        # Fallback in case no test samples got created
        if len(test_indices) == 0 and len(df) > 1:
            all_idx = list(df.index)
            rng.shuffle(all_idx)
            split_idx = int(len(all_idx) * 0.8)
            train_indices = all_idx[:split_idx]
            test_indices = all_idx[split_idx:]

        train_df = df.loc[train_indices].reset_index(drop=True)
        test_df = df.loc[test_indices].reset_index(drop=True)

        self.logger.info(
            f"✅ Total: {len(df)}, Train: {len(train_df)}, Test: {len(test_df)} (stratified by SubQueryType)"
        )

        # ---------- SAVE RAW 20% TEST SPLIT BEFORE TRAINING ----------
        directory = os.path.dirname(self.finedtunnedmodelpath)
        eval_dir = os.path.join(directory, "evaluation")
        os.makedirs(eval_dir, exist_ok=True)

        raw_test_path = os.path.join(eval_dir, "test_raw_before_training.csv")
        raw_cols = ["text", "SubQueryType", "classification_label", "sentiment_label"]
        test_df[raw_cols].to_csv(raw_test_path, index=False)
        self.logger.info(f"💾 Saved raw test split to {raw_test_path}")

        MAX_LEN = 256
        batch_size = 16
        tokenizer = self.tokenizer

        # ========== LEVEL 1 TRAINING: QueryType + Sentiment ==========
        self.logger.info("")
        self.logger.info("=" * 80)
        self.logger.info("🎯 LEVEL 1 TRAINING: QueryType + Sentiment")
        self.logger.info("=" * 80)

        # ---------- TRAIN DATA (80%) ----------
        tokenized_texts = [tokenizer.encode(text, add_special_tokens=True) for text in train_df['text']]

        # Create attention masks
        train_masks = [[int(token_id > 0) for token_id in input_id] for input_id in tokenized_texts]

        train_inputs = pad_sequences(
            tokenized_texts, maxlen=MAX_LEN, dtype='long', value=0,
            truncating='post', padding='post'
        )
        train_masks = pad_sequences(
            train_masks, maxlen=MAX_LEN, dtype='long', value=0,
            truncating='post', padding='post'
        )
        df_classification = train_df["classification"].astype(np.int64)
        df_sentiments = train_df['sentiment'].astype(np.int64)
        train_data = TensorDataset(
            torch.tensor(train_inputs),
            torch.tensor(train_masks),
            torch.tensor(df_classification.values),
            torch.tensor(df_sentiments.values)
        )
        train_sampler = RandomSampler(train_data)
        train_dataloader = DataLoader(train_data, sampler=train_sampler, batch_size=batch_size)

        model = self.model
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.logger.info(f"🖥️  Using device: {device}")
        model.to(device)

        optimizer = AdamW(model.parameters(), lr=2e-5, eps=1e-8)
        criterion = nn.CrossEntropyLoss()

        # Initialize training logger
        train_logger = TrainingLogger(self.logger, self.NUM_TRAIN_EPOCHS, len(train_dataloader))
        train_logger.start_training("Level 1 (QueryType + Sentiment)")

        try:
            for epoch in range(self.NUM_TRAIN_EPOCHS):
                train_logger.start_epoch(epoch)
                model.train()
                epoch_loss = 0.0
                epoch_class_loss = 0.0
                epoch_sent_loss = 0.0
                
                for step, batch in enumerate(train_dataloader):
                    input_ids = batch[0].to(device)
                    attention_mask = batch[1].to(device)
                    classification_labels = batch[2].to(device)
                    sentiment_labels = batch[3].to(device)

                    optimizer.zero_grad()

                    classification_logits, sentiment_logits, classification_probs, sentiment_probs = \
                        model(input_ids, attention_mask)

                    classification_loss = criterion(classification_logits, classification_labels)
                    sentiment_loss = criterion(sentiment_logits, sentiment_labels)

                    loss = classification_loss + sentiment_loss

                    loss.backward()
                    optimizer.step()

                    epoch_loss += loss.item()
                    epoch_class_loss += classification_loss.item()
                    epoch_sent_loss += sentiment_loss.item()
                    
                    train_logger.log_batch(
                        epoch, step, loss.item(),
                        Class=classification_loss.item(),
                        Sent=sentiment_loss.item()
                    )
                
                avg_loss = epoch_loss / len(train_dataloader)
                train_logger.end_epoch(epoch, avg_loss)
                
        except Exception as e:
            self.logger.error(f"❌ Training error: {str(e)}", exc_info=True)
            raise

        train_logger.end_training()

        # Save Level 1 model with bundled encoders
        self.logger.info("💾 Saving Level 1 model...")
        directory = os.path.dirname(self.finedtunnedmodelpath)
        if not os.path.exists(directory):
            os.makedirs(directory)

        # Attach encoders before saving
        model.set_encoders(
            self.processed_label_encoders['classification'],
            self.processed_label_encoders['sentiment']
        )
        model.SaveModel(self.finedtunnedmodelpath)
        tokenizer.save_pretrained(self.finedtunnedmodelpath)
        self.logger.info("✅ Level 1 model saved with bundled encoders")

        # ========== LEVEL 2 TRAINING: SubQueryType ==========
        self.logger.info("")
        self.logger.info("=" * 80)
        self.logger.info("🎯 LEVEL 2 TRAINING: SubQueryType")
        self.logger.info("=" * 80)

        subquery_encoder = self.processed_label_encoders["subquery"]

        if not hasattr(subquery_encoder, "classes_") or len(subquery_encoder.classes_) == 0:
            self.logger.info("🔧 Fitting SubQueryType label encoder")
            subquery_encoder.fit(df["SubQueryType"].astype(str))

        y_subquery = subquery_encoder.transform(train_df["SubQueryType"])

        tokenized_subq = [
            tokenizer.encode(text, add_special_tokens=True)
            for text in train_df["subquery_input_text"]
        ]

        subq_masks = [[int(t > 0) for t in ids] for ids in tokenized_subq]

        subq_inputs = pad_sequences(
            tokenized_subq, maxlen=MAX_LEN, truncating="post", padding="post"
        )
        subq_masks = pad_sequences(
            subq_masks, maxlen=MAX_LEN, truncating="post", padding="post"
        )

        subq_dataset = TensorDataset(
            torch.tensor(subq_inputs, dtype=torch.long),
            torch.tensor(subq_masks, dtype=torch.long),
            torch.tensor(y_subquery, dtype=torch.long)
        )
        subq_loader = DataLoader(
            subq_dataset,
            batch_size=batch_size,
            shuffle=True
        )

        subq_model = SubQueryNNModel(
            self.finedtunnedmodelpath,
            num_labels=len(subquery_encoder.classes_)
        )

        subq_model.to(device)
        subq_optimizer = AdamW(subq_model.parameters(), lr=2e-5)
        subq_loss_fn = nn.CrossEntropyLoss()

        # Initialize Level 2 training logger
        subq_train_logger = TrainingLogger(self.logger, self.NUM_TRAIN_EPOCHS, len(subq_loader))
        subq_train_logger.start_training("Level 2 (SubQueryType)")

        for epoch in range(self.NUM_TRAIN_EPOCHS):
            subq_train_logger.start_epoch(epoch)
            epoch_loss = 0.0

            for step, (ids, masks, labels) in enumerate(subq_loader):
                ids = ids.to(device)
                masks = masks.to(device)
                labels = labels.to(device).long()

                subq_optimizer.zero_grad()

                logits = subq_model(ids, masks)

                # unwrap if tuple (safety)
                if isinstance(logits, (tuple, list)):
                    logits = logits[0]

                loss = subq_loss_fn(logits, labels)
                loss.backward()
                subq_optimizer.step()

                epoch_loss += loss.item()
                subq_train_logger.log_batch(epoch, step, loss.item())

            avg_loss = epoch_loss / len(subq_loader)
            subq_train_logger.end_epoch(epoch, avg_loss)

        subq_train_logger.end_training()

        # Save Level 2 model with bundled encoder
        self.logger.info("💾 Saving Level 2 SubQuery model...")
        subq_dir = os.path.join(self.config["MODEL_DIR"], "subquery_model")
        os.makedirs(subq_dir, exist_ok=True)
        
        # Attach encoder before saving
        subq_model.set_encoder(subquery_encoder)
        subq_model.save(subq_dir)
        self.logger.info("✅ Level 2 model saved with bundled encoder")

        # ========== EVALUATION ON 20% TEST SPLIT ==========
        if len(test_df) > 0:
            self.logger.info("")
            self.logger.info("=" * 80)
            self.logger.info("📊 EVALUATION ON 20% TEST SPLIT")
            self.logger.info("=" * 80)

            model.eval()
            model.to(device)

            test_tokenized = [tokenizer.encode(text, add_special_tokens=True) for text in test_df["text"]]
            test_masks = [[int(token_id > 0) for token_id in input_id] for input_id in test_tokenized]

            test_inputs = pad_sequences(
                test_tokenized, maxlen=MAX_LEN, dtype='long', value=0,
                truncating='post', padding='post'
            )
            test_masks = pad_sequences(
                test_masks, maxlen=MAX_LEN, dtype='long', value=0,
                truncating='post', padding='post'
            )

            test_dataset = TensorDataset(
                torch.tensor(test_inputs),
                torch.tensor(test_masks),
            )
            test_sampler = SequentialSampler(test_dataset)
            test_loader = DataLoader(test_dataset, sampler=test_sampler, batch_size=batch_size)

            all_class_true_ids = test_df["classification"].astype(np.int64).tolist()
            all_sent_true_ids = test_df["sentiment"].astype(np.int64).tolist()

            all_class_pred_ids = []
            all_sent_pred_ids = []
            all_class_score = []
            all_sent_score = []

            with torch.no_grad():
                for batch in test_loader:
                    input_ids, attention_mask = [t.to(device) for t in batch]

                    classification_logits, sentiment_logits, _, _ = model(input_ids, attention_mask)

                    class_probs = nn.Softmax(dim=1)(classification_logits)
                    sent_probs = nn.Softmax(dim=1)(sentiment_logits)

                    class_preds = torch.argmax(class_probs, dim=1)
                    sent_preds = torch.argmax(sent_probs, dim=1)

                    all_class_pred_ids.extend(class_preds.cpu().numpy().tolist())
                    all_sent_pred_ids.extend(sent_preds.cpu().numpy().tolist())
                    
                    # Collect confidence scores
                    all_class_score.extend(
                        class_probs.gather(1, class_preds.unsqueeze(1)).squeeze(1).cpu().numpy().tolist()
                    )
                    all_sent_score.extend(
                        sent_probs.gather(1, sent_preds.unsqueeze(1)).squeeze(1).cpu().numpy().tolist()
                    )

            # Decode ids back to label strings
            class_encoder = self.processed_label_encoders['classification']
            sent_encoder = self.processed_label_encoders['sentiment']

            decoded_class_true = class_encoder.inverse_transform(np.array(all_class_true_ids))
            decoded_class_pred = class_encoder.inverse_transform(np.array(all_class_pred_ids))

            decoded_sent_true = sent_encoder.inverse_transform(np.array(all_sent_true_ids))
            decoded_sent_pred = sent_encoder.inverse_transform(np.array(all_sent_pred_ids))

            # ========== SAVE TEST PREDICTIONS CSV ==========
            eval_df = pd.DataFrame({
                "text": test_df["text"],
                "SubQueryType": test_df["SubQueryType"],
                "classification_true": decoded_class_true,
                "classification_pred": decoded_class_pred,
                "classification_score": all_class_score,
                "sentiment_true": decoded_sent_true,
                "sentiment_pred": decoded_sent_pred,
                "sentiment_score": all_sent_score,
            })

            eval_path = os.path.join(eval_dir, "test_predictions.csv")
            eval_df.to_csv(eval_path, index=False)
            self.logger.info(f"💾 Saved test predictions to {eval_path}")

            # Calculate metrics
            class_accuracy = accuracy_score(decoded_class_true, decoded_class_pred)
            class_f1_weighted = f1_score(decoded_class_true, decoded_class_pred, average='weighted')
            class_report = classification_report(decoded_class_true, decoded_class_pred)

            sent_accuracy = accuracy_score(decoded_sent_true, decoded_sent_pred)
            sent_f1_weighted = f1_score(decoded_sent_true, decoded_sent_pred, average='weighted')
            sent_report = classification_report(decoded_sent_true, decoded_sent_pred)

            self.logger.info(f"✅ Classification Accuracy: {class_accuracy:.4f}")
            self.logger.info(f"✅ Classification F1 (weighted): {class_f1_weighted:.4f}")
            self.logger.info(f"✅ Sentiment Accuracy: {sent_accuracy:.4f}")
            self.logger.info(f"✅ Sentiment F1 (weighted): {sent_f1_weighted:.4f}")

            # ========== SAVE METRICS.TXT ==========
            metrics_path = os.path.join(eval_dir, "metrics.txt")
            with open(metrics_path, "w", encoding="utf-8") as f:
                f.write("=== Classification Metrics ===\n")
                f.write(f"Accuracy: {class_accuracy:.4f}\n")
                f.write(f"F1 (weighted): {class_f1_weighted:.4f}\n\n")
                f.write("Classification report:\n")
                f.write(class_report)
                f.write("\n\n=== Sentiment Metrics ===\n")
                f.write(f"Accuracy: {sent_accuracy:.4f}\n")
                f.write(f"F1 (weighted): {sent_f1_weighted:.4f}\n\n")
                f.write("Sentiment report:\n")
                f.write(sent_report)

            self.logger.info(f"💾 Saved evaluation metrics to {metrics_path}")

            # Save to database
            run_id = self.save_metrics_to_sqlite(
                class_accuracy, class_f1_weighted,
                sent_accuracy, sent_f1_weighted,
                len(train_df), len(test_df)
            )

            # Save detailed reports
            self.save_full_classification_report_to_sqlite(run_id, "classification", decoded_class_true, decoded_class_pred)
            self.save_full_classification_report_to_sqlite(run_id, "sentiment", decoded_sent_true, decoded_sent_pred)

            self.logger.info("=" * 80)
            self.logger.info("✅ TRAINING AND EVALUATION COMPLETE")
            self.logger.info("=" * 80)

    # ========== 3-LEVEL HIERARCHICAL TRAINING METHODS ==========
    
    def prepare_3level_data(self, train_df):
        """
        Prepare training data for all three levels
        
        Expected columns:
        - text: email content
        - masterdepartment: Level 1 target
        - department: Level 2 target
        - querytype: Level 3 target
        """
        
        from sklearn.preprocessing import LabelEncoder
        
        # Level 1: Encode MasterDepartment
        level1_encoder = LabelEncoder()
        train_df['masterdepartment_encoded'] = level1_encoder.fit_transform(
            train_df['masterdepartment']
        )
        
        # Level 2: Encode Department
        level2_encoder = LabelEncoder()
        train_df['department_encoded'] = level2_encoder.fit_transform(
            train_df['department']
        )
        
        # Level 3: Encode QueryType
        level3_encoder = LabelEncoder()
        train_df['querytype_encoded'] = level3_encoder.fit_transform(
            train_df['querytype']
        )
        
        self.logger.info(f"📊 Level 1 (MasterDepartment) classes: {len(level1_encoder.classes_)}")
        self.logger.info(f"📊 Level 2 (Department) classes: {len(level2_encoder.classes_)}")
        self.logger.info(f"📊 Level 3 (QueryType) classes: {len(level3_encoder.classes_)}")
        
        return train_df, level1_encoder, level2_encoder, level3_encoder
    
    def create_single_level_dataloader(self, texts, labels, batch_size=16, shuffle=True):
        """Create PyTorch DataLoader for single level training"""
        
        # Tokenize texts
        tokenized_texts = [
            self.tokenizer.encode(
                text,
                add_special_tokens=True,
                max_length=256,
                truncation=True
            )
            for text in texts
        ]
        
        attention_masks = [[int(t > 0) for t in ids] for ids in tokenized_texts]
        
        # Pad sequences
        inputs = pad_sequences(
            tokenized_texts,
            maxlen=256,
            dtype='long',
            value=0,
            truncating='post',
            padding='post'
        )
        
        masks = pad_sequences(
            attention_masks,
            maxlen=256,
            dtype='long',
            value=0,
            truncating='post',
            padding='post'
        )
        
        # Create tensors
        dataset = TensorDataset(
            torch.tensor(inputs),
            torch.tensor(masks),
            torch.tensor(labels, dtype=torch.long)
        )
        
        # Create dataloader
        sampler = RandomSampler(dataset) if shuffle else SequentialSampler(dataset)
        dataloader = DataLoader(
            dataset,
            sampler=sampler,
            batch_size=batch_size
        )
        
        return dataloader
    
    def train_single_level_model(self, model, dataloader, level_name, epochs=3):
        """
        Train a single level model
        
        Args:
            model: The model to train
            dataloader: Training data
            level_name: Name for logging (e.g., "Level 1 - MasterDepartment")
            epochs: Number of training epochs
        """
        
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model.to(device)
        
        # Optimizer
        optimizer = AdamW(model.parameters(), lr=2e-5, eps=1e-8)
        
        # Loss function
        loss_fn = nn.CrossEntropyLoss()
        
        # Training logger
        train_logger = TrainingLogger(
            self.logger,
            total_epochs=epochs,
            total_batches=len(dataloader)
        )
        
        train_logger.start_training(model_name=level_name)
        
        for epoch in range(epochs):
            train_logger.start_epoch(epoch)
            
            model.train()
            total_loss = 0
            
            for batch_idx, batch in enumerate(dataloader):
                input_ids, attention_mask, labels = [t.to(device) for t in batch]
                
                # Forward pass
                optimizer.zero_grad()
                logits = model(input_ids, attention_mask)
                
                # Calculate loss
                loss = loss_fn(logits, labels)
                total_loss += loss.item()
                
                # Backward pass
                loss.backward()
                optimizer.step()
                
                # Log progress
                train_logger.log_batch(epoch, batch_idx, loss.item())
            
            # Calculate average loss
            avg_loss = total_loss / len(dataloader)
            train_logger.end_epoch(epoch, avg_loss)
        
        train_logger.end_training()
        
        return model
    
    def train_3level_hierarchy(self, train_df, epochs=3, model_name='bert-base-uncased'):
        """
        Train all 3 levels sequentially:
        Level 1: Email → MasterDepartment
        Level 2: Email + MasterDepartment → Department  
        Level 3: Email + MasterDepartment + Department → QueryType
        
        Args:
            train_df: DataFrame with columns: text, masterdepartment, department, querytype
            epochs: Number of epochs for each level
            model_name: Base model name (default: bert-base-uncased)
        """
        
        self.logger.info("=" * 80)
        self.logger.info("🚀 STARTING 3-LEVEL HIERARCHICAL TRAINING")
        self.logger.info("=" * 80)
        
        # Prepare data
        train_df, level1_encoder, level2_encoder, level3_encoder = \
            self.prepare_3level_data(train_df)
        
        # ===== LEVEL 1: Email → MasterDepartment =====
        self.logger.info("=" * 80)
        self.logger.info("🎯 LEVEL 1: Email → MasterDepartment")
        self.logger.info("=" * 80)
        
        num_labels_l1 = len(level1_encoder.classes_)
        level1_model = Level1Model(model_name, num_labels_l1)
        
        texts_l1 = train_df['text'].tolist()
        labels_l1 = train_df['masterdepartment_encoded'].values
        dataloader_l1 = self.create_single_level_dataloader(texts_l1, labels_l1)
        
        level1_model = self.train_single_level_model(
            level1_model,
            dataloader_l1,
            level_name="Level 1 - MasterDepartment",
            epochs=epochs
        )
        
        level1_model.set_encoder(level1_encoder)
        level1_save_path = str(pathlib.Path(self.config['MODEL_DIR']) / "level1_masterdepartment")
        level1_model.save(level1_save_path)
        self.logger.info(f"✅ Level 1 model saved to {level1_save_path}")
        
        # ===== LEVEL 2: Email + MasterDepartment → Department =====
        self.logger.info("=" * 80)
        self.logger.info("🎯 LEVEL 2: Email + MasterDepartment → Department")
        self.logger.info("=" * 80)
        
        num_labels_l2 = len(level2_encoder.classes_)
        level2_model = Level2Model(model_name, num_labels_l2)
        
        texts_l2 = [
            f"MasterDepartment: {row['masterdepartment']} Email: {row['text']}"
            for _, row in train_df.iterrows()
        ]
        labels_l2 = train_df['department_encoded'].values
        dataloader_l2 = self.create_single_level_dataloader(texts_l2, labels_l2)
        
        level2_model = self.train_single_level_model(
            level2_model,
            dataloader_l2,
            level_name="Level 2 - Department",
            epochs=epochs
        )
        
        level2_model.set_encoder(level2_encoder)
        level2_save_path = str(pathlib.Path(self.config['MODEL_DIR']) / "level2_department")
        level2_model.save(level2_save_path)
        self.logger.info(f"✅ Level 2 model saved to {level2_save_path}")
        
        # ===== LEVEL 3: Email + MasterDepartment + Department → QueryType =====
        self.logger.info("=" * 80)
        self.logger.info("🎯 LEVEL 3: Email + MasterDepartment + Department → QueryType")
        self.logger.info("=" * 80)
        
        num_labels_l3 = len(level3_encoder.classes_)
        level3_model = Level3Model(model_name, num_labels_l3)
        
        texts_l3 = [
            f"MasterDepartment: {row['masterdepartment']} "
            f"Department: {row['department']} "
            f"Email: {row['text']}"
            for _, row in train_df.iterrows()
        ]
        labels_l3 = train_df['querytype_encoded'].values
        dataloader_l3 = self.create_single_level_dataloader(texts_l3, labels_l3)
        
        level3_model = self.train_single_level_model(
            level3_model,
            dataloader_l3,
            level_name="Level 3 - QueryType",
            epochs=epochs
        )
        
        level3_model.set_encoder(level3_encoder)
        level3_save_path = str(pathlib.Path(self.config['MODEL_DIR']) / "level3_querytype")
        level3_model.save(level3_save_path)
        self.logger.info(f"✅ Level 3 model saved to {level3_save_path}")
        
        self.logger.info("=" * 80)
        self.logger.info("✅ ALL 3 LEVELS TRAINED AND SAVED SUCCESSFULLY!")
        self.logger.info("=" * 80)
        self.logger.info(f"📁 Level 1 saved at: {level1_save_path}")
        self.logger.info(f"📁 Level 2 saved at: {level2_save_path}")
        self.logger.info(f"📁 Level 3 saved at: {level3_save_path}")
        self.logger.info("=" * 80)

    def fit_external(self, event, data, tasks, **kwargs):
        """External training wrapper"""
        self.logger.info("🔄 External training initiated")
        return self.fit(event, data, tasks, **kwargs)

    def predict(self, tasks: List[Dict], texts: str, context: Optional[Dict] = None, **kwargs):
        """
        STREAMLINED INFERENCE PIPELINE
        
        Just pass email text, automatically routes through:
        1. Level 1: Email → QueryType + Sentiment
        2. Level 2: Email + predicted QueryType → SubQueryType
        
        Returns all predictions in a single result.
        """
        
        self.logger.info(f"🔮 Running inference on {len(texts)} email(s)...")

        def getSubQueryAttrName(attrs):
            return attrs == "subquery"

        from_name_subquery, to_name_subquery, _ = \
            self.label_interface.get_first_tag_occurence(
                "Taxonomy", "HyperText", getSubQueryAttrName
            )

        def getClassificationAttrName(attrs):
            return attrs == 'classification'

        def getSentimentAttrName(attrs):
            return attrs == 'sentiment'

        from_name_classification, to_name_classification, _ = \
            self.label_interface.get_first_tag_occurence(
                'Taxonomy', 'HyperText', getClassificationAttrName
            )

        from_name_sentiment, to_name_sentiment, _ = \
            self.label_interface.get_first_tag_occurence(
                'Taxonomy', 'HyperText', getSentimentAttrName
            )

        tokenizer = self.tokenizer

        # Tokenize input texts
        tokenized_texts = [
            tokenizer.encode(
                text['text'] if not isinstance(text, str) else text,
                add_special_tokens=True
            )
            for text in texts
        ]

        attention_mask = [[int(t > 0) for t in ids] for ids in tokenized_texts]

        MAX_LEN = 256
        batch_size = 16

        _inputs = pad_sequences(
            tokenized_texts,
            maxlen=MAX_LEN,
            dtype='long',
            value=0,
            truncating='post',
            padding='post'
        )

        _masks = pad_sequences(
            attention_mask,
            maxlen=MAX_LEN,
            dtype='long',
            value=0,
            truncating='post',
            padding='post'
        )

        dataset = TensorDataset(
            torch.tensor(_inputs),
            torch.tensor(_masks)
        )

        dataloader = DataLoader(
            dataset,
            sampler=SequentialSampler(dataset),
            batch_size=batch_size
        )

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        self.model.to(device)
        self.model.eval()

        if self.subquery_model is not None:
            self.subquery_model.to(device)
            self.subquery_model.eval()
            self.logger.info("✅ Level 2 model active - SubQuery predictions enabled")
        else:
            self.logger.info("ℹ️  Level 2 model not loaded - SubQuery predictions skipped")

        predictions = []

        # Global index to align batch ↔ texts
        global_text_idx = 0

        with torch.no_grad():
            for batch in dataloader:
                input_ids, attention_mask = [t.to(device) for t in batch]
    
                # ========== LEVEL 1: QueryType + Sentiment ==========
                classification_logits, sentiment_logits, _, _ = \
                    self.model(input_ids, attention_mask)

                classification_probs = torch.softmax(classification_logits, dim=1)
                sentiment_probs = torch.softmax(sentiment_logits, dim=1)

                classification_preds = torch.argmax(classification_probs, dim=1)
                sentiment_preds = torch.argmax(sentiment_probs, dim=1)

                decoded_classification_preds = \
                    self.processed_label_encoders['classification'] \
                    .inverse_transform(classification_preds.cpu().numpy())

                decoded_sentiment_preds = \
                    self.processed_label_encoders['sentiment'] \
                    .inverse_transform(sentiment_preds.cpu().numpy())

                for i in range(len(classification_preds)):
                    text = texts[global_text_idx]
                    global_text_idx += 1

                    # ---------- QUERY TYPE ----------
                    predictions.append({
                        "from_name": from_name_classification,
                        "to_name": to_name_classification,
                        "type": "taxonomy",
                        "value": {
                            "taxonomy": [
                                decoded_classification_preds[i].split(" > ")
                            ],
                            "score": classification_probs[i][classification_preds[i]].item()
                        }
                    })

                    # ---------- SENTIMENT ----------
                    predictions.append({
                        "from_name": from_name_sentiment,
                        "to_name": to_name_sentiment,
                        "type": "taxonomy",
                        "value": {
                            "taxonomy": [decoded_sentiment_preds[i]],
                            "score": sentiment_probs[i][sentiment_preds[i]].item()
                        }
                    })

                    # ========== LEVEL 2: SUB QUERY TYPE ==========
                    if self.subquery_model is not None:
                        # Use PREDICTED QueryType from Level 1
                        conditional_text = (
                            f"QueryType: {decoded_classification_preds[i]} "
                            f"Email: {text}"
                        )

                        subq_ids = tokenizer.encode(
                            conditional_text,
                            add_special_tokens=True,
                            max_length=256,
                            truncation=True
                        )

                        subq_mask = [int(t > 0) for t in subq_ids]

                        subq_logits = self.subquery_model(
                            torch.tensor([subq_ids]).to(device),
                            torch.tensor([subq_mask]).to(device)
                        )

                        # Unwrap if model returns tuple
                        if isinstance(subq_logits, (tuple, list)):
                            subq_logits = subq_logits[0]

                        subq_probs = torch.softmax(subq_logits, dim=1)
                        subq_idx = torch.argmax(subq_probs, dim=1).item()

                        subquery_label = \
                            self.processed_label_encoders["subquery"] \
                            .inverse_transform([subq_idx])[0]

                        predictions.append({
                            "from_name": from_name_subquery,
                            "to_name": to_name_subquery,
                            "type": "taxonomy",
                            "value": {
                                "taxonomy": [subquery_label],
                                "score": subq_probs[0][subq_idx].item()
                            }
                        })

        self.logger.info(f"✅ Inference complete - Generated {len(predictions)} predictions")
        return predictions