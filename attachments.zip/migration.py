import requests
import sys
import os
from dotenv import load_dotenv

# ==========================================
# LOAD ENVIRONMENT VARIABLES
# ==========================================
load_dotenv()

SOURCE_URL = os.getenv("SOURCE_URL")
SOURCE_API_KEY = os.getenv("SOURCE_API_KEY")

DEST_URL = os.getenv("DEST_URL")
DEST_API_KEY = os.getenv("DEST_API_KEY")

# ==========================================
# VALIDATE ENV CONFIG
# ==========================================
missing = [
    name for name, value in {
        "SOURCE_URL": SOURCE_URL,
        "SOURCE_API_KEY": SOURCE_API_KEY,
        "DEST_URL": DEST_URL,
        "DEST_API_KEY": DEST_API_KEY
    }.items() if not value
]

if missing:
    print(f" Missing environment variables: {', '.join(missing)}")
    sys.exit(1)

# ==========================================
# HELPERS
# ==========================================
def get_headers(token):
    return {
        "Authorization": f"Token {token}",
        "Content-Type": "application/json"
    }

def ask_project_id():
    try:
        project_id = int(input("👉 Enter SOURCE Project ID to migrate: ").strip())
        return project_id
    except ValueError:
        print(" Project ID must be a number.")
        sys.exit(1)

# ==========================================
# MIGRATION LOGIC
# ==========================================
def run_migration():
    SOURCE_PROJECT_ID = ask_project_id()

    print(f"\n--- Starting Migration ---")
    print(f"Source      : {SOURCE_URL}")
    print(f"Destination : {DEST_URL}")
    print(f"Project ID  : {SOURCE_PROJECT_ID}")

    # 1. GET PROJECT DETAILS
    print(f"\n[1/4] Fetching project details...")
    resp = requests.get(
        f"{SOURCE_URL}/api/projects/{SOURCE_PROJECT_ID}",
        headers=get_headers(SOURCE_API_KEY)
    )

    if resp.status_code != 200:
        print(f" Error fetching project: {resp.text}")
        sys.exit(1)

    project_data = resp.json()
    project_title = project_data["title"]
    label_config = project_data["label_config"]
    description = project_data.get("description", "")

    print(f" Found Project: {project_title}")

    # 2. EXPORT TASKS
    print(f"[2/4] Exporting tasks...")
    export_url = (
        f"{SOURCE_URL}/api/projects/{SOURCE_PROJECT_ID}/export"
        "?exportType=JSON&download_all_tasks=true"
    )

    resp = requests.get(export_url, headers=get_headers(SOURCE_API_KEY))

    if resp.status_code != 200:
        print(f" Export failed: {resp.text}")
        sys.exit(1)

    tasks_data = resp.json()
    print(f" Exported {len(tasks_data)} tasks")

    if not tasks_data:
        print(" No tasks found. Migration stopped.")
        sys.exit(1)

    # PATCH DATA KEYS
    print("🔧 Patching data keys (text → review)")
    for task in tasks_data:
        if "data" in task and "text" in task["data"] and "review" not in task["data"]:
            task["data"]["review"] = task["data"]["text"]

    # 3. CREATE PROJECT ON DESTINATION
    print(f"[3/4] Creating project on destination...")
    resp = requests.post(
        f"{DEST_URL}/api/projects",
        headers=get_headers(DEST_API_KEY),
        json={
            "title": project_title,
            "description": description,
            "label_config": label_config
        }
    )

    if resp.status_code != 201:
        print(f" Project creation failed: {resp.text}")
        sys.exit(1)

    new_project_id = resp.json()["id"]
    print(f" Created new project #{new_project_id}")

    # 4. IMPORT TASKS
    print(f"[4/4] Importing tasks...")
    resp = requests.post(
        f"{DEST_URL}/api/projects/{new_project_id}/import",
        headers=get_headers(DEST_API_KEY),
        json=tasks_data
    )

    if resp.status_code == 201:
        print("\n MIGRATION COMPLETE")
        print(f" {DEST_URL}/projects/{new_project_id}")
    else:
        print(f"❌ Import failed: {resp.text}")

if __name__ == "__main__":
    run_migration()
