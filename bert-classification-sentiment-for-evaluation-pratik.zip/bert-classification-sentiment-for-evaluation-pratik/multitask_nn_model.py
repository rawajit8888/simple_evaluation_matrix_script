import os
import json
import torch
import torch.nn as nn
from transformers import BertModel
from dataprocessing.processlabels import ProcessLabels


class MultiTaskNNModel(nn.Module):
    def __init__(self, modelname, classificationlabel_length=1000, sentimentlabel_length=2):
        super(MultiTaskNNModel, self).__init__()

        self.bert = BertModel.from_pretrained(modelname)
        self.dropout = nn.Dropout(0.1)

        self.classifier = nn.Linear(self.bert.config.hidden_size, classificationlabel_length)
        self.sentiment_classifier = nn.Linear(self.bert.config.hidden_size, sentimentlabel_length)

        self.classifier_softmax = nn.Softmax(dim=1)
        self.sentiment_softmax = nn.Softmax(dim=1)

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(input_ids, attention_mask=attention_mask)
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)

        classifier_logits = self.classifier(pooled_output)
        sentiment_logits = self.sentiment_classifier(pooled_output)

        classifier_probs = self.classifier_softmax(classifier_logits)
        sentiment_probs = self.sentiment_softmax(sentiment_logits)

        return classifier_logits, sentiment_logits, classifier_probs, sentiment_probs

    def SaveModel(self, directorypath):
        os.makedirs(directorypath, exist_ok=True)
        self.bert.save_pretrained(directorypath)

        # FIX Bug 1: use os.path.join instead of Windows backslash paths
        torch.save(self.state_dict(), os.path.join(directorypath, 'multitask_model.pth'))

        # FIX Bug 2: save label output sizes so reload_model() can reconstruct
        # the exact architecture and load weights without dimension mismatches
        model_config = {
            'classification_labels': self.classifier.out_features,
            'sentiment_labels': self.sentiment_classifier.out_features
        }
        with open(os.path.join(directorypath, 'model_config.json'), 'w') as f:
            json.dump(model_config, f)

    def LoadModel(self, directorypath):
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # FIX Bug 1: use os.path.join instead of Windows backslash paths
        model_path = os.path.join(directorypath, 'multitask_model.pth')
        loaded_state = torch.load(model_path, map_location=device)

        current_state = self.state_dict()
        filtered_state = {
            k: v for k, v in loaded_state.items()
            if k in current_state and v.size() == current_state[k].size()
        }
        current_state.update(filtered_state)
        self.load_state_dict(current_state, strict=False)
        self.eval()
