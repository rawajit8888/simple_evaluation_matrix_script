import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from transformers import BertTokenizer
import pickle


class ProcessLabels:
    def __init__(self, parsed_label_config, model_dir):
        self.parsed_label_config = parsed_label_config
        # FIX Bug 1: use os.path.join instead of Windows backslash paths
        self.encoder_dir = os.path.join(str(model_dir), 'encoders')
        os.makedirs(self.encoder_dir, exist_ok=True)
        self.initEncoder()

    def initEncoder(self):
        self.labels = {
            "classification": {"encoder": None},
            "sentiment": {"encoder": None}
        }
        self.getLabelEncoder('classification')
        self.getLabelEncoder('sentiment')

    def saveLabelEncoderFile(self, labelencoder, filepath):
        with open(filepath, 'wb') as file:
            pickle.dump(labelencoder, file)

    def getLabelEncoder(self, labeltype):
        try:
            if self.labels[labeltype]["encoder"] is None:
                # FIX Bug 1: use os.path.join instead of Windows backslash paths
                file_path = os.path.join(self.encoder_dir, f'{labeltype}_label_encoder.pkl')
                if os.path.exists(file_path):
                    with open(file_path, 'rb') as file:
                        label_encoder = pickle.load(file)

                    new_labels = (
                        [label for label in self.parsed_label_config[labeltype]['labels']
                         if label not in label_encoder.classes_.tolist()]
                        if self.parsed_label_config is not None else []
                    )
                    if len(new_labels) > 0:
                        new_labels_np = np.array(new_labels, dtype=label_encoder.classes_.dtype)
                        updated_classes = np.concatenate((label_encoder.classes_, new_labels_np))
                        label_encoder.fit(updated_classes)
                        self.saveLabelEncoderFile(label_encoder, file_path)
                else:
                    if self.parsed_label_config is None:
                        # No config and no saved encoder — cannot initialise
                        return None
                    label_encoder = LabelEncoder()
                    label_encoder.fit(self.parsed_label_config[labeltype]['labels'])
                    self.saveLabelEncoderFile(label_encoder, file_path)

                self.labels[labeltype]["encoder"] = label_encoder

            return self.labels[labeltype]["encoder"]
        except Exception as e:
            print(f"[getLabelEncoder] ERROR for '{labeltype}': {e}")
            return None

    def __getitem__(self, key):
        return self.labels[key]["encoder"]
