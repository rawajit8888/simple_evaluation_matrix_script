import torch
import torch.nn as nn
from transformers import BertModel
from dataprocessing.processlabels import ProcessLabels

class MultiTaskNNModel(nn.Module):
    def __init__(self, modelname,classificationlabel_length = 1000, sentimentlabel_length =2):
        super(MultiTaskNNModel, self).__init__()

        self.bert = BertModel.from_pretrained(modelname)
        
        self.dropout = nn.Dropout(0.1)

        self.classifier = nn.Linear(self.bert.config.hidden_size, classificationlabel_length)
        self.sentiment_classifier = nn.Linear(self.bert.config.hidden_size, sentimentlabel_length)
        # self.ner = nn.Linear(self.bert.config.hidden_size, len(processedlabels.labels["ner"]["encoder"].classes_))

        self.classifier_softmax = nn.Softmax(dim=1)
        self.sentiment_softmax = nn.Softmax(dim=1)
        # self.ner_softmax = nn.Softmax(dim=1)

    def forward(self, input_ids, attention_mask):
      outputs = self.bert(input_ids, attention_mask=attention_mask)
      pooled_output = outputs[1]
      pooled_output = self.dropout(pooled_output)

      classifier_logits = self.classifier(pooled_output)
      sentiment_logits = self.sentiment_classifier(pooled_output)
    #   ner_logits = self.ner(pooled_output)

      classifier_probs = self.classifier_softmax(classifier_logits)
    #   ner_probs = self.ner_softmax(ner_logits)
      sentiment_probs = self.sentiment_softmax(sentiment_logits)

    #   return classifier_logits, sentiment_logits, ner_logits, classifier_probs, sentiment_probs, ner_probs
      return classifier_logits, sentiment_logits, classifier_probs, sentiment_probs
    
    def SaveModel(self,directorypath):
       self.bert.save_pretrained(directorypath)
       torch.save(self.state_dict(), f'{directorypath}\\multitask_model.pth')
    
    def LoadModel(self, directorypath):
        # self.bert = BertModel.from_pretrained(directorypath)
        device = torch.device( 'cuda' if torch.cuda.is_available() else 'cpu')
        loaded_state = torch.load( f'{directorypath}\\multitask_model.pth',map_location=device)
        current_state = self.state_dict()
        filtered_state = {k: v for k, v in loaded_state.items() if k in current_state and v.size() == current_state[k].size()}
        current_state.update(filtered_state)
        self.load_state_dict(current_state,strict=False)
        self.eval()
   
       
       

       
    