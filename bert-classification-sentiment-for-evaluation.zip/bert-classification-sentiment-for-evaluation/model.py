import os
import pathlib
import re
import label_studio_sdk
import logging

from typing import List, Dict, Optional
from label_studio_ml.model import LabelStudioMLBase
from label_studio_ml.response import ModelResponse

from transformers import pipeline, Pipeline
# from itertools import groupby
# from transformers import AutoModelForTokenClassification, TrainingArguments, Trainer, AutoTokenizer,AdamW
# from transformers import DataCollatorForTokenClassification
# from datasets import Dataset, ClassLabel, Value, Sequence, Features
# from functools import partial
# import torch
# import torch.nn as nn
# from dataprocessing.processlabels import ProcessLabels
# from torch.utils.data import DataLoader

from multi_task_model import MultiTaskBertModel
from dataprocessing.processlabels import ProcessLabels

logger = logging.getLogger(__name__)
_model: Optional[Pipeline] = None

MODEL_DIR = os.getenv('MODEL_DIR', './results/bert-classification-sentiment')

Config={
        "MULTI_TASK":{
        'MODEL_DIR':os.getenv('MODEL_DIR', MODEL_DIR),
        'FINETUNED_MODEL_NAME':os.getenv('FINETUNED_MULTICLASS_MODEL_NAME', 'finetuned_multitask_model'),
        # 'BASELINE_MODEL_NAME':os.getenv('BASELINE_MULTICLASS_MODEL_NAME', 'google-bert/bert-base-multilingual-cased')
        'BASELINE_MODEL_NAME':os.getenv('BASELINE_MULTICLASS_MODEL_NAME', 'baseline-model')
    }
}
multi_classs_model = MultiTaskBertModel(config=Config["MULTI_TASK"], logger= logger)

def reload_model():
    multi_classs_model.reload_model()


reload_model()

class MultiTaskBert(LabelStudioMLBase):
    """Custom ML Backend model
    """
    LABEL_STUDIO_HOST = os.getenv('LABEL_STUDIO_HOST', 'http://localhost:8080')
    LABEL_STUDIO_API_KEY = os.getenv('LABEL_STUDIO_API_KEY', '5d1a32bb14129720a48ddeb09b5cc99f1e39cc7c')
    START_TRAINING_EACH_N_UPDATES = int(os.getenv('START_TRAINING_EACH_N_UPDATES', 10))
    LEARNING_RATE = float(os.getenv('LEARNING_RATE', 1e-3))
    NUM_TRAIN_EPOCHS = int(os.getenv('NUM_TRAIN_EPOCHS', 100))
    WEIGHT_DECAY = float(os.getenv('WEIGHT_DECAY', 0.01))

    def __init__(self, **kwargs):
        super(MultiTaskBert, self).__init__(**kwargs)
        if hasattr(self,'label_interface'):
            multi_classs_model.label_interface = self.label_interface
            multi_classs_model.parsed_label_config = self.parsed_label_config
            multi_classs_model.processed_label_encoders = ProcessLabels(self.parsed_label_config,Config["MULTI_TASK"]['MODEL_DIR'])

        # self.load_model()



    def get_labels(self):
        li = self.label_interface
        from_name, _, _ = li.get_first_tag_occurence('Labels', 'Text')
        tag = li.get_tag(from_name)
        return tag.labels
        
    def setup(self):
        """Configure any parameters of your model here
        """
        self.set("model_version", f'{self.__class__.__name__}-v0.0.1')
        # self.processed_label_encoders = ProcessLabels(self.parsed_label_config)
        # self.device = torch.device( 'cuda' if torch.cuda.is_available() else 'cpu')
        # self.load_model()

       

    
    def predict(self, tasks: List[Dict], context: Optional[Dict] = None, **kwargs) -> ModelResponse:
        """ Write your inference logic here
            :param tasks: [Label Studio tasks in JSON format](https://labelstud.io/guide/task_format.html)
            :param context: [Label Studio context in JSON format](https://labelstud.io/guide/ml_create#Implement-prediction-logic)
            :return model_response
                ModelResponse(predictions=predictions) with
                predictions: [Predictions array in JSON format](https://labelstud.io/guide/export.html#Label-Studio-JSON-format-of-annotated-tasks)
        """
        
        li = self.label_interface
        from_name, to_name, value = li.get_first_tag_occurence('Taxonomy', 'HyperText')
        texts = [self.preload_task_data(task, task['data']['html']) for task in tasks]
        # texts = [self.preload_task_data(task, task['data']['text']) for task in tasks]

        results = multi_classs_model.predict(tasks,texts,context,**kwargs)

        predictions=[]
        if results:
            predictions.append({
                'result': results,
                'score': sum(d["value"]["score"] for d in results) / len(results),
                'model_version': self.get('model_version')
            })
        
        return ModelResponse(predictions=predictions, model_version=self.get('model_version'))
        

    def predict_external(self, texts, **kwargs) -> ModelResponse:
        """ Write your inference logic here
            :param tasks: [Label Studio tasks in JSON format](https://labelstud.io/guide/task_format.html)
            :param context: [Label Studio context in JSON format](https://labelstud.io/guide/ml_create#Implement-prediction-logic)
            :return model_response
                ModelResponse(predictions=predictions) with
                predictions: [Predictions array in JSON format](https://labelstud.io/guide/export.html#Label-Studio-JSON-format-of-annotated-tasks)
        """

        results = multi_classs_model.predict(None,texts,None,**kwargs)
        
        predictions=[]
        if results:
            predictions.append({
                'result': results,
                'score': sum(d["value"]["score"] for d in results) / len(results),
                'model_version': self.get('model_version')
            })
        
        return ModelResponse(predictions=predictions, model_version=self.get('model_version'))
        

       

    def _get_tasks(self, project_id):
        # download annotated tasks from Label Studio
        ls = label_studio_sdk.Client(self.LABEL_STUDIO_HOST, self.LABEL_STUDIO_API_KEY)
        project = ls.get_project(id=project_id)
        tasks = project.get_labeled_tasks()
        return tasks

    def tokenize_and_align_labels(self, examples, tokenizer):
        """
        From example https://huggingface.co/docs/transformers/en/tasks/token_classification#preprocess
        """
        tokenized_inputs = tokenizer(examples["tokens"], truncation=True, is_split_into_words=True)

        labels = []
        for i, label in enumerate(examples[f"ner_tags"]):
            word_ids = tokenized_inputs.word_ids(batch_index=i)  # Map tokens to their respective word.
            previous_word_idx = None
            label_ids = []
            for word_idx in word_ids:  # Set the special tokens to -100.
                if word_idx is None:
                    label_ids.append(-100)
                elif word_idx != previous_word_idx:  # Only label the first token of a given word.
                    label_ids.append(label[word_idx])
                else:
                    label_ids.append(-100)
                previous_word_idx = word_idx
            labels.append(label_ids)

        tokenized_inputs["labels"] = labels
        return tokenized_inputs

    def fit(self, event, data, **kwargs):
        """Download dataset from Label Studio and prepare data for training in BERT
        """
        if event not in ('ANNOTATION_CREATED', 'ANNOTATION_UPDATED', 'START_TRAINING'):
            logger.info(f"Skip training: event {event} is not supported")
            return

        project_id = data['project']['id']
        tasks = self._get_tasks(project_id)
        
        if len(tasks) % self.START_TRAINING_EACH_N_UPDATES != 0 and event != 'START_TRAINING':
            logger.info(f"Skip training: {len(tasks)} tasks are not multiple of {self.START_TRAINING_EACH_N_UPDATES}")
            return

        # we need to convert Label Studio NER annotations to hugingface NER format in datasets
        # for example:
        # {'id': '0',
        #  'ner_tags': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 8, 8, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0],
        #  'tokens': ['@paulwalk', 'It', "'s", 'the', 'view', 'from', 'where', 'I', "'m", 'living', 'for', 'two', 'weeks', '.', 'Empire', 'State', 'Building', '=', 'ESB', '.', 'Pretty', 'bad', 'storm', 'here', 'last', 'evening', '.']
        # }
        ds_raw = []
        # def getClassificationAttrName(attrs):
        #     return attrs == 'classification'
        
        # def getSentimentAttrName(attrs):
        #     return attrs == 'sentiment'
        
        
        # from_name_classification, to_name_classification, value_classification = self.label_interface.get_first_tag_occurence('Taxonomy', 'HyperText',getClassificationAttrName)
        # from_name_sentiment, to_name_sentiment, value_sentiment = self.label_interface.get_first_tag_occurence('Taxonomy', 'HyperText',getSentimentAttrName)
        # from_name_ner, to_name_ner, value_ner = self.label_interface.get_first_tag_occurence('HyperTextLabels', 'HyperText')
        multi_classs_model.preload_task_data = self.preload_task_data
        multi_classs_model.fit(event, data,tasks, **kwargs)
        reload_model()

    def fit_external(self, event, data, **kwargs):
            """Download dataset from Label Studio and prepare data for training in BERT
            """
            if event not in ('ANNOTATION_CREATED', 'ANNOTATION_UPDATED', 'START_TRAINING'):
                logger.info(f"Skip training: event {event} is not supported")
                return
            tasks= data["tasks"]
            multi_classs_model.fit_external(event, data,tasks, **kwargs)
            reload_model()

