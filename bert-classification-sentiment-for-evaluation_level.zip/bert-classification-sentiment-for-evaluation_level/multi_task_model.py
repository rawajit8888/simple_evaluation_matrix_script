import os
import pathlib
import re
import numpy as np
import pandas as pd
from tqdm import tqdm
import time
from datetime import datetime, timedelta

import label_studio_sdk
import logging

from typing import List, Dict, Optional
from label_studio_ml.model import LabelStudioMLBase
from label_studio_ml.response import ModelResponse

import torch
import torch.optim as optim
import torch.nn as nn

from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
from torch.utils.data import RandomSampler
from torch.utils.data import SequentialSampler

from keras.utils import pad_sequences
from transformers import pipeline, Pipeline, BertModel
from transformers import AdamW
from itertools import groupby
from transformers import AutoModelForTokenClassification, TrainingArguments, Trainer, AutoTokenizer, AdamW
from transformers import DataCollatorForTokenClassification
from datasets import Dataset, ClassLabel, Value, Sequence, Features
from functools import partial
from dataprocessing.processlabels import ProcessLabels
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
import pickle

logger = logging.getLogger(__name__)


# ========== Single Level Model Class (Used for all 3 levels) ==========

class SingleLevelModel(nn.Module):
    """
    Single-level BERT classification model with bundled label encoder.
    Used for MasterDepartment, Department, and QueryType models.
    """

    def __init__(self, modelname, num_labels, level_name="level"):
        super(SingleLevelModel, self).__init__()

        self.level_name = level_name
        self.bert = BertModel.from_pretrained(modelname)
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(
            self.bert.config.hidden_size,
            num_labels
        )

        # Store encoder (will be set during training)
        self.encoder = None

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )

        pooled_output = outputs[1]  # CLS pooled output
        pooled_output = self.dropout(pooled_output)

        logits = self.classifier(pooled_output)
        return logits

    def set_encoder(self, encoder):
        """Set label encoder before saving"""
        self.encoder = encoder
        logger.info(f"✓ Encoder attached to {self.level_name} model")

    def save(self, directorypath):
        """Save model with bundled encoder"""
        try:
            os.makedirs(directorypath, exist_ok=True)

            # Save BERT backbone
            logger.info(f"✓ Saving {self.level_name} BERT to {directorypath}")
            self.bert.save_pretrained(directorypath)

            # Save classifier head
            classifier_path = os.path.join(directorypath, f"{self.level_name}_classifier.pth")
            logger.info(f"✓ Saving classifier head to {classifier_path}")
            torch.save(
                self.classifier.state_dict(),
                classifier_path
            )

            # Save bundled encoder
            encoder_path = os.path.join(directorypath, f'{self.level_name}_encoder.pkl')
            logger.info(f"✓ Saving {self.level_name} encoder to {encoder_path}")
            with open(encoder_path, 'wb') as f:
                pickle.dump(self.encoder, f)

            logger.info(f"✓ {self.level_name} model and encoder saved successfully")

        except Exception as e:
            logger.error(f"✗ Error saving {self.level_name} model: {e}")
            raise

    def load(self, directorypath):
        """Load model with bundled encoder"""
        try:
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

            # Reload BERT
            logger.info(f"✓ Loading {self.level_name} BERT from {directorypath}")
            self.bert = BertModel.from_pretrained(directorypath)

            # Reload classifier head
            classifier_path = os.path.join(directorypath, f"{self.level_name}_classifier.pth")
            logger.info(f"✓ Loading classifier head from {classifier_path}")
            self.classifier.load_state_dict(
                torch.load(
                    classifier_path,
                    map_location=device
                )
            )

            # Load bundled encoder
            encoder_path = os.path.join(directorypath, f'{self.level_name}_encoder.pkl')
            if os.path.exists(encoder_path):
                logger.info(f"✓ Loading bundled {self.level_name} encoder from {encoder_path}")
                with open(encoder_path, 'rb') as f:
                    self.encoder = pickle.load(f)
                logger.info(f"✓ {self.level_name} model and encoder loaded successfully")
            else:
                logger.warning(f"⚠ No bundled encoder found for {self.level_name} - using external encoder")

            self.eval()

        except Exception as e:
            logger.error(f"✗ Error loading {self.level_name} model: {e}")
            raise

    def get_encoder(self):
        """Safely retrieve encoder"""
        if self.encoder is None:
            raise ValueError(f"{self.level_name} encoder is None")
        return self.encoder


# ========== TrainingLogger Class ==========

class TrainingLogger:
    """Enhanced training logger with time estimates"""

    def __init__(self, logger, total_epochs, total_batches):
        self.logger = logger
        self.total_epochs = total_epochs
        self.total_batches = total_batches
        self.start_time = None
        self.epoch_times = []

    def start_training(self, model_name="Model"):
        """Mark training start"""
        self.start_time = time.time()
        self.logger.info("=" * 80)
        self.logger.info(f"🚀 {model_name} TRAINING STARTED")
        self.logger.info(f"📊 Total Epochs: {self.total_epochs}")
        self.logger.info(f"📦 Total Batches per Epoch: {self.total_batches}")
        self.logger.info(f"⏰ Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("=" * 80)

    def start_epoch(self, epoch):
        """Mark epoch start"""
        self.epoch_start = time.time()
        self.logger.info("")
        self.logger.info(f"📈 EPOCH {epoch + 1}/{self.total_epochs}")
        self.logger.info("-" * 80)

    def log_batch(self, epoch, batch_idx, loss, **extra_losses):
        """Log batch progress"""
        if batch_idx % 10 == 0:  # Log every 10 batches
            progress = (batch_idx / self.total_batches) * 100
            loss_str = f"Loss: {loss:.4f}"

            # Add extra losses if provided
            for name, value in extra_losses.items():
                loss_str += f" | {name}: {value:.4f}"

            self.logger.info(
                f"  Batch {batch_idx}/{self.total_batches} ({progress:.1f}%) | {loss_str}"
            )

    def end_epoch(self, epoch, avg_loss):
        """Mark epoch end and estimate remaining time"""
        epoch_time = time.time() - self.epoch_start
        self.epoch_times.append(epoch_time)

        # Calculate ETA
        avg_epoch_time = np.mean(self.epoch_times)
        remaining_epochs = self.total_epochs - (epoch + 1)
        eta_seconds = avg_epoch_time * remaining_epochs
        eta = timedelta(seconds=int(eta_seconds))

        self.logger.info("-" * 80)
        self.logger.info(f"✓ Epoch {epoch + 1} complete | Avg Loss: {avg_loss:.4f}")
        self.logger.info(f"⏱ Time: {timedelta(seconds=int(epoch_time))} | ETA: {eta}")

    def end_training(self):
        """Mark training end"""
        total_time = time.time() - self.start_time
        self.logger.info("=" * 80)
        self.logger.info(f"✅ TRAINING COMPLETE")
        self.logger.info(f"⏱ Total Time: {timedelta(seconds=int(total_time))}")
        self.logger.info("=" * 80)


# ========== Main MultiTaskBertModel Class ==========

class MultiTaskBertModel:
    """
    3-Level Hierarchical Email Classification System

    Level 1: Email → MasterDepartment
    Level 2: Email + MasterDepartment → Department
    Level 3: Email + MasterDepartment + Department → QueryType

    Features:
    - 3 separate model files
    - Cascading predictions during inference
    - Bundled encoders with each model
    """

    # Class constants
    LABEL_STUDIO_HOST = os.getenv('LABEL_STUDIO_HOST', 'http://localhost:8080')
    LABEL_STUDIO_API_KEY = os.getenv('LABEL_STUDIO_API_KEY', '830eb6d65978e36293a63635717da95bbbcb7a9d')
    START_TRAINING_EACH_N_UPDATES = int(os.getenv('START_TRAINING_EACH_N_UPDATES', 10))
    LEARNING_RATE = float(os.getenv('LEARNING_RATE', 1e-3))
    NUM_TRAIN_EPOCHS = int(os.getenv('NUM_TRAIN_EPOCHS', 10))
    WEIGHT_DECAY = float(os.getenv('WEIGHT_DECAY', 0.01))

    def __init__(self, config, logger, label_interface=None, parsed_label_config=None):
        self.config = config
        self.logger = logger
        self.label_interface = label_interface
        self.parsed_label_config = parsed_label_config

        # Initialize label processors
        self.processed_label_encoders = ProcessLabels(
            self.parsed_label_config,
            pathlib.Path(self.config['MODEL_DIR'])
        )

        self.model_dir = pathlib.Path(config['MODEL_DIR'])

        # Model paths for 3 levels
        self.masterdept_model_path = self.model_dir / "masterdepartment_model"
        self.dept_model_path = self.model_dir / "department_model"
        self.querytype_model_path = self.model_dir / "querytype_model"

        # Create directories
        for path in [self.masterdept_model_path, self.dept_model_path, self.querytype_model_path]:
            os.makedirs(path, exist_ok=True)

        # Initialize models (will be loaded in reload_model)
        self.masterdept_model = None
        self.dept_model = None
        self.querytype_model = None

        # Tokenizer (will be loaded in reload_model)
        self.tokenizer = None

        # Training config
        self.learning_rate = 2e-5
        self.num_epochs = 5
        self.batch_size = 16

        # Database for metrics
        self.db_path = self.model_dir / "training_metrics.db"
        self._init_metrics_db()

    def _init_metrics_db(self):
        """Initialize SQLite database for metrics tracking"""
        import sqlite3
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        # Create runs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS training_runs (
                run_id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                level VARCHAR(50),
                accuracy REAL,
                f1_weighted REAL,
                train_size INTEGER,
                test_size INTEGER
            )
        ''')

        # Create metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id INTEGER,
                task VARCHAR(50),
                metric VARCHAR(100),
                value REAL,
                FOREIGN KEY (run_id) REFERENCES training_runs (run_id)
            )
        ''')

        conn.commit()
        conn.close()
        logger.info(f"✓ Metrics database initialized at {self.db_path}")

    def reload_model(self):
        """Load all 3 trained models"""
        try:
            # ===== FIX: Use valid HuggingFace model identifier =====
            # Check if baseline-model folder exists locally, otherwise use bert-base-uncased
            baseline_model_dir = self.model_dir / "baseline-model"

            if os.path.exists(baseline_model_dir) and os.path.exists(baseline_model_dir / "config.json"):
                baseline_model = str(baseline_model_dir)
                self.logger.info(f"✓ Using local baseline model from {baseline_model}")
            else:
                # Fallback to standard HuggingFace model
                baseline_model = self.config.get('BASELINE_MODEL_NAME', 'bert-base-uncased')
                self.logger.info(f"✓ Using HuggingFace baseline model: {baseline_model}")

            # Initialize tokenizer (try finetuned path first, then baseline)
            finetuned_path = str(self.model_dir / self.config.get('FINETUNED_MODEL_NAME', 'finetuned_multitask_model'))

            # Try loading tokenizer from various sources
            tokenizer_loaded = False

            # 1. Try finetuned model path
            if os.path.exists(finetuned_path) and os.path.exists(os.path.join(finetuned_path, 'tokenizer_config.json')):
                try:
                    self.logger.info(f"📥 Loading tokenizer from finetuned model: {finetuned_path}")
                    self.tokenizer = AutoTokenizer.from_pretrained(finetuned_path)
                    tokenizer_loaded = True
                except Exception as e:
                    self.logger.warning(f"⚠ Could not load tokenizer from finetuned model: {e}")

            # 2. Try baseline-model folder
            if not tokenizer_loaded and os.path.exists(baseline_model_dir):
                try:
                    self.logger.info(f"📥 Loading tokenizer from local baseline-model folder")
                    self.tokenizer = AutoTokenizer.from_pretrained(str(baseline_model_dir))
                    tokenizer_loaded = True
                except Exception as e:
                    self.logger.warning(f"⚠ Could not load tokenizer from baseline-model folder: {e}")

            # 3. Try any trained model that has a tokenizer
            if not tokenizer_loaded:
                for model_path in [self.masterdept_model_path, self.dept_model_path, self.querytype_model_path]:
                    if os.path.exists(model_path / 'tokenizer_config.json'):
                        try:
                            self.logger.info(f"📥 Loading tokenizer from {model_path}")
                            self.tokenizer = AutoTokenizer.from_pretrained(str(model_path))
                            tokenizer_loaded = True
                            break
                        except Exception as e:
                            continue

            # 4. Fallback to HuggingFace BERT
            if not tokenizer_loaded:
                self.logger.info(f"📥 Loading tokenizer from HuggingFace: {baseline_model}")
                self.tokenizer = AutoTokenizer.from_pretrained(baseline_model)
                tokenizer_loaded = True

            if not tokenizer_loaded:
                raise ValueError("Could not load tokenizer from any source")

            # Try to load each model
            # Level 1: MasterDepartment
            if os.path.exists(self.masterdept_model_path / "masterdepartment_classifier.pth"):
                self.logger.info("📥 Loading MasterDepartment model...")
                
                # Load encoder from saved file to get correct number of labels
                encoder_path = self.masterdept_model_path / "masterdepartment_encoder.pkl"
                if os.path.exists(encoder_path):
                    with open(encoder_path, 'rb') as f:
                        masterdept_encoder = pickle.load(f)
                    num_masterdept_labels = len(masterdept_encoder.classes_)
                    self.logger.info(f"✓ Loaded encoder with {num_masterdept_labels} classes from saved model")
                else:
                    # Fallback if encoder file doesn't exist
                    num_masterdept_labels = len(self.processed_label_encoders['masterdepartment'].classes_) if \
                    self.processed_label_encoders['masterdepartment'] else 10
                    self.logger.warning(f"⚠ Using fallback: {num_masterdept_labels} labels")
                
                self.masterdept_model = SingleLevelModel(baseline_model, num_masterdept_labels, "masterdepartment")
                self.masterdept_model.load(str(self.masterdept_model_path))
                self.logger.info("✓ MasterDepartment model loaded")
            else:
                self.logger.warning("⚠ MasterDepartment model not found - will be created on first training")

            # Level 2: Department
            if os.path.exists(self.dept_model_path / "department_classifier.pth"):
                self.logger.info("📥 Loading Department model...")
                
                # Load encoder from saved file to get correct number of labels
                encoder_path = self.dept_model_path / "department_encoder.pkl"
                if os.path.exists(encoder_path):
                    with open(encoder_path, 'rb') as f:
                        dept_encoder = pickle.load(f)
                    num_dept_labels = len(dept_encoder.classes_)
                    self.logger.info(f"✓ Loaded encoder with {num_dept_labels} classes from saved model")
                else:
                    # Fallback if encoder file doesn't exist
                    num_dept_labels = len(self.processed_label_encoders['department'].classes_) if \
                    self.processed_label_encoders['department'] else 10
                    self.logger.warning(f"⚠ Using fallback: {num_dept_labels} labels")
                
                self.dept_model = SingleLevelModel(baseline_model, num_dept_labels, "department")
                self.dept_model.load(str(self.dept_model_path))
                self.logger.info("✓ Department model loaded")
            else:
                self.logger.warning("⚠ Department model not found - will be created on first training")

            # Level 3: QueryType
            if os.path.exists(self.querytype_model_path / "querytype_classifier.pth"):
                self.logger.info("📥 Loading QueryType model...")
                
                # Load encoder from saved file to get correct number of labels
                encoder_path = self.querytype_model_path / "querytype_encoder.pkl"
                if os.path.exists(encoder_path):
                    with open(encoder_path, 'rb') as f:
                        querytype_encoder = pickle.load(f)
                    num_querytype_labels = len(querytype_encoder.classes_)
                    self.logger.info(f"✓ Loaded encoder with {num_querytype_labels} classes from saved model")
                else:
                    # Fallback if encoder file doesn't exist
                    num_querytype_labels = len(self.processed_label_encoders['querytype'].classes_) if \
                    self.processed_label_encoders['querytype'] else 10
                    self.logger.warning(f"⚠ Using fallback: {num_querytype_labels} labels")
                
                self.querytype_model = SingleLevelModel(baseline_model, num_querytype_labels, "querytype")
                self.querytype_model.load(str(self.querytype_model_path))
                self.logger.info("✓ QueryType model loaded")
            else:
                self.logger.warning("⚠ QueryType model not found - will be created on first training")

        except Exception as e:
            self.logger.error(f"✗ Error loading models: {e}")
            self.logger.error(f"📋 Stack trace:", exc_info=True)
            raise

    def _get_device(self):
        """Get compute device"""
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.logger.info(f"🖥 Using device: {device}")
        return device

    def preload_task_data(self, task, value):
        """Preload task data (compatibility method from old system)"""
        return value

    def _tokenize_and_pad(self, texts, tokenizer, max_len):
        """Tokenize and pad text sequences"""
        input_ids = []
        attention_masks = []

        for text in texts:
            encoded = tokenizer.encode_plus(
                text,
                add_special_tokens=True,
                max_length=max_len,
                padding='max_length',
                truncation=True,
                return_attention_mask=True,
                return_tensors='pt'
            )

            input_ids.append(encoded['input_ids'])
            attention_masks.append(encoded['attention_mask'])

        input_ids = torch.cat(input_ids, dim=0)
        attention_masks = torch.cat(attention_masks, dim=0)

        return input_ids, attention_masks

    def _create_dataloader(self, input_ids, attention_masks, labels=None, batch_size=16, shuffle=True):
        """Create PyTorch DataLoader"""
        if labels is not None:
            dataset = TensorDataset(input_ids, attention_masks, labels)
        else:
            dataset = TensorDataset(input_ids, attention_masks)

        if shuffle:
            sampler = RandomSampler(dataset)
        else:
            sampler = SequentialSampler(dataset)

        dataloader = DataLoader(dataset, sampler=sampler, batch_size=batch_size)
        return dataloader

    def _decode_predictions(self, predictions, label_type):
        """Decode numerical predictions to labels"""
        try:
            encoder = None

            # Try bundled encoder first
            if label_type == "masterdepartment" and self.masterdept_model:
                encoder = self.masterdept_model.get_encoder()
            elif label_type == "department" and self.dept_model:
                encoder = self.dept_model.get_encoder()
            elif label_type == "querytype" and self.querytype_model:
                encoder = self.querytype_model.get_encoder()

            # Fallback to external encoders
            if encoder is None and self.processed_label_encoders:
                encoder = self.processed_label_encoders[label_type]

            if encoder is None:
                self.logger.warning(f"⚠ No encoder found for {label_type}")
                return [f"Unknown_{i}" for i in predictions]

            # Convert predictions to numpy if tensor
            if isinstance(predictions, torch.Tensor):
                predictions = predictions.cpu().numpy()

            decoded = encoder.inverse_transform(predictions)
            return decoded.tolist() if hasattr(decoded, 'tolist') else list(decoded)

        except Exception as e:
            self.logger.error(f"✗ Error decoding {label_type} predictions: {e}")
            return [f"Error_{i}" for i in range(len(predictions))]

    def _prepare_dataset_for_level(self, tasks, level):
        """
        Prepare dataset for specific level with HIERARCHICAL TAXONOMY PARSING

        Parses the single 'classification' taxonomy field which contains hierarchical paths
        like "HR > HRHELPDESK > Myzone > My zone app issue"

        Level 1 (masterdepartment): Email → MasterDepartment (1st part of path)
        Level 2 (department): Email + MasterDepartment → Department (2nd part of path)
        Level 3 (querytype): Email + MasterDepartment + Department → QueryType (3rd part of path)
        """
        texts = []
        labels = []

        self.logger.info(f"🔍 Processing {len(tasks)} tasks for level: {level}")

        for task_idx, task in enumerate(tasks):
            try:
                # Check if task has annotations
                if not task.get('annotations'):
                    if task_idx < 3:  # Only log first 3 to avoid spam
                        self.logger.warning(f"  Task {task_idx + 1}: No annotations found")
                    continue

                # Get email text from data
                email_text = None
                data = task.get('data', {})

                # Try different data field names
                if 'html' in data:
                    email_text = self.preload_task_data(task, data['html'])
                elif 'text' in data:
                    email_text = data['text']
                elif 'email' in data:
                    email_text = data['email']
                else:
                    if task_idx < 3:
                        self.logger.warning(
                            f"  Task {task_idx + 1}: No text data found. Available keys: {list(data.keys())}")
                    continue

                if not email_text or email_text.strip() == '':
                    if task_idx < 3:
                        self.logger.warning(f"  Task {task_idx + 1}: Empty email text")
                    continue

                # Get annotations - handle both single annotation and list
                annotations_list = task['annotations']
                if not isinstance(annotations_list, list):
                    annotations_list = [annotations_list]

                # Use the first completed annotation
                annotation = None
                for ann in annotations_list:
                    if ann.get('was_cancelled') is False or 'result' in ann:
                        annotation = ann
                        break

                if not annotation:
                    if task_idx < 3:
                        self.logger.warning(f"  Task {task_idx + 1}: No valid annotation found")
                    continue

                # Get annotation results
                annotation_results = annotation.get('result', [])

                if not annotation_results:
                    if task_idx < 3:
                        self.logger.warning(f"  Task {task_idx + 1}: Empty annotation results")
                    continue

                # ========== EXTRACT HIERARCHICAL CLASSIFICATION PATH ==========
                classification_path = None

                for item in annotation_results:
                    item_type = item.get('type', '')
                    from_name = item.get('from_name', '').lower()

                    # Debug: print what we're seeing for first task
                    if task_idx == 0:
                        self.logger.info(f"    Annotation item: type={item_type}, from_name='{from_name}'")

                    # Only process taxonomy items
                    if item_type != 'taxonomy':
                        continue

                    # Get taxonomy path
                    value = item.get('value', {})
                    taxonomy_data = value.get('taxonomy', [])

                    # Handle different taxonomy formats
                    if isinstance(taxonomy_data, list) and len(taxonomy_data) > 0:
                        # Could be [['HR > HRHELPDESK > Myzone']] or ['HR > HRHELPDESK > Myzone']
                        if isinstance(taxonomy_data[0], list) and len(taxonomy_data[0]) > 0:
                            # Format: [['HR > HRHELPDESK > Myzone']]
                            raw_path = taxonomy_data[0][0] if taxonomy_data[0] else None
                        else:
                            # Format: ['HR > HRHELPDESK > Myzone']
                            raw_path = taxonomy_data[0] if taxonomy_data else None
                    else:
                        raw_path = None

                    # Identify which taxonomy this is based on from_name
                    if 'classification' in from_name or 'query' in from_name or 'category' in from_name:
                        classification_path = raw_path
                        if task_idx == 0:
                            self.logger.info(f"    ✓ Found Classification Path: {classification_path}")

                # ========== PARSE THE HIERARCHICAL PATH ==========
                masterdept_label = None
                dept_label = None
                querytype_label = None

                if classification_path:
                    # Split by ' > ' (with spaces) or '>' (without spaces)
                    # Handle both formats just in case
                    if ' > ' in classification_path:
                        parts = [p.strip() for p in classification_path.split(' > ')]
                    elif '>' in classification_path:
                        parts = [p.strip() for p in classification_path.split('>')]
                    else:
                        # Single level path - treat entire string as masterdept
                        parts = [classification_path.strip()]

                    # AUTO-EXPAND: If only 1 level provided, create full 3-level hierarchy
                    if len(parts) == 1:
                        # Use the single label as both masterdept and dept, add default querytype
                        original_label = parts[0]
                        masterdept_label = original_label.split()[0] if ' ' in original_label else original_label  # "Admin" from "Admin Malad"
                        dept_label = original_label  # "Admin Malad"
                        querytype_label = "General"  # Default query type
                        if task_idx == 0:
                            self.logger.info(f"    🔧 Auto-expanded 1-level label '{original_label}' to 3 levels")
                    else:
                        # Extract hierarchy levels normally (0-indexed)
                        if len(parts) >= 1:
                            masterdept_label = parts[0]  # First level: HR
                        if len(parts) >= 2:
                            dept_label = parts[1]  # Second level: HRHELPDESK
                        if len(parts) >= 3:
                            querytype_label = parts[2]  # Third level: Myzone
                        # We ignore the 4th level (SubQueryType) for the 3-level model

                    # Log what we found for first task
                    if task_idx == 0:
                        self.logger.info(f"    Parsed Hierarchy ({len(parts)} original levels → 3 effective levels):")
                        self.logger.info(f"      Level 1 (MasterDept): '{masterdept_label}'")
                        self.logger.info(f"      Level 2 (Dept): '{dept_label}'")
                        self.logger.info(f"      Level 3 (QueryType): '{querytype_label}'")
                else:
                    if task_idx < 3:
                        self.logger.warning(f"  Task {task_idx + 1}: No classification path found")
                    continue

                # ========== PREPARE TEXT AND LABEL BASED ON LEVEL ==========
                if level == "masterdepartment":
                    # Level 1: Just email → MasterDepartment
                    if masterdept_label:
                        texts.append(email_text)
                        labels.append(masterdept_label)
                    else:
                        if task_idx < 3:
                            self.logger.warning(
                                f"  Task {task_idx + 1}: Missing MasterDepartment label (need at least 1 level)")

                elif level == "department":
                    # Level 2: Email + MasterDepartment(actual) → Department
                    if masterdept_label and dept_label:
                        conditional_text = f"MasterDepartment: {masterdept_label} Email: {email_text}"
                        texts.append(conditional_text)
                        labels.append(dept_label)
                    else:
                        if task_idx < 3:
                            actual_levels = len([x for x in [masterdept_label, dept_label] if x is not None])
                            self.logger.warning(
                                f"  Task {task_idx + 1}: Missing labels - need at least 2 levels (got {actual_levels} levels)")

                elif level == "querytype":
                    # Level 3: Email + MasterDepartment(actual) + Department(actual) → QueryType
                    if masterdept_label and dept_label and querytype_label:
                        conditional_text = f"MasterDepartment: {masterdept_label} Department: {dept_label} Email: {email_text}"
                        texts.append(conditional_text)
                        labels.append(querytype_label)
                    else:
                        if task_idx < 3:
                            self.logger.warning(
                                f"  Task {task_idx + 1}: Missing labels - need at least 3 levels (got {len([x for x in [masterdept_label, dept_label, querytype_label] if x])} levels)")

            except Exception as e:
                self.logger.error(f"  Task {task_idx + 1}: Error processing - {e}", exc_info=True)
                continue

        self.logger.info(f"📦 Prepared {len(texts)} samples for {level} training")

        # If no samples found, provide helpful debug info
        if len(texts) == 0:
            self.logger.error(f"❌ NO SAMPLES EXTRACTED FOR {level.upper()}!")
            self.logger.error(f"   ")
            self.logger.error(f"   Common causes:")
            self.logger.error(f"   1. Classification taxonomy not annotated")
            self.logger.error(f"   2. Hierarchy doesn't have enough levels:")
            if level == "masterdepartment":
                self.logger.error(f"      - Need at least 1 level (e.g., 'HR')")
            elif level == "department":
                self.logger.error(f"      - Need at least 2 levels (e.g., 'HR > HRHELPDESK')")
            elif level == "querytype":
                self.logger.error(f"      - Need at least 3 levels (e.g., 'HR > HRHELPDESK > Myzone')")
            self.logger.error(f"   3. Field name is not 'classification' in Label Studio config")
            self.logger.error(f"   ")
            self.logger.error(f"   Your Label Studio config should have:")
            self.logger.error(f'   <Taxonomy name="classification" toName="text" ...>')
            self.logger.error(f"   ")

        return texts, labels

    def _train_single_level(self, train_texts, train_labels, test_texts, test_labels,
                            level_name, model, encoder):
        """Train a single level model"""

        device = self._get_device()
        model.to(device)

        # Encode labels
        train_labels_encoded = encoder.transform(train_labels)
        test_labels_encoded = encoder.transform(test_labels)

        # Tokenize
        MAX_LEN = 256
        train_inputs, train_masks = self._tokenize_and_pad(train_texts, self.tokenizer, MAX_LEN)
        test_inputs, test_masks = self._tokenize_and_pad(test_texts, self.tokenizer, MAX_LEN)

        train_labels_tensor = torch.tensor(train_labels_encoded, dtype=torch.long)
        test_labels_tensor = torch.tensor(test_labels_encoded, dtype=torch.long)

        # Create dataloaders
        train_dataloader = self._create_dataloader(
            train_inputs, train_masks, train_labels_tensor,
            batch_size=self.batch_size, shuffle=True
        )

        test_dataloader = self._create_dataloader(
            test_inputs, test_masks, test_labels_tensor,
            batch_size=self.batch_size, shuffle=False
        )

        # Optimizer and loss
        optimizer = torch.optim.AdamW(model.parameters(), lr=self.learning_rate)
        criterion = nn.CrossEntropyLoss()

        # Training logger
        train_logger = TrainingLogger(
            self.logger,
            self.num_epochs,
            len(train_dataloader)
        )

        train_logger.start_training(f"{level_name.upper()} MODEL")

        # Training loop
        for epoch in range(self.num_epochs):
            train_logger.start_epoch(epoch)

            model.train()
            total_loss = 0

            for batch_idx, batch in enumerate(train_dataloader):
                input_ids, attention_mask, labels = [t.to(device) for t in batch]

                optimizer.zero_grad()

                logits = model(input_ids, attention_mask)
                loss = criterion(logits, labels)

                loss.backward()
                optimizer.step()

                total_loss += loss.item()

                train_logger.log_batch(epoch, batch_idx, loss.item())

            avg_loss = total_loss / len(train_dataloader)
            train_logger.end_epoch(epoch, avg_loss)

        train_logger.end_training()

        # Evaluation
        self.logger.info(f"📊 Evaluating {level_name} model...")
        model.eval()

        all_preds = []
        all_true = []

        with torch.no_grad():
            for batch in test_dataloader:
                input_ids, attention_mask, labels = [t.to(device) for t in batch]

                logits = model(input_ids, attention_mask)
                preds = torch.argmax(logits, dim=1)

                all_preds.extend(preds.cpu().numpy())
                all_true.extend(labels.cpu().numpy())

        # Decode predictions
        decoded_preds = encoder.inverse_transform(all_preds)
        decoded_true = encoder.inverse_transform(all_true)

        # Calculate metrics
        accuracy = accuracy_score(decoded_true, decoded_preds)
        f1_weighted = f1_score(decoded_true, decoded_preds, average='weighted')

        self.logger.info(f"✓ {level_name.upper()} - Accuracy: {accuracy:.4f}, F1: {f1_weighted:.4f}")

        # Save model with bundled encoder
        model.set_encoder(encoder)

        if level_name == "masterdepartment":
            model.save(str(self.masterdept_model_path))
        elif level_name == "department":
            model.save(str(self.dept_model_path))
        elif level_name == "querytype":
            model.save(str(self.querytype_model_path))

        # Save metrics to database
        self._save_level_metrics(level_name, accuracy, f1_weighted,
                                 len(train_texts), len(test_texts),
                                 decoded_true, decoded_preds)

        return accuracy, f1_weighted

    def _save_level_metrics(self, level, accuracy, f1_weighted, train_size, test_size, y_true, y_pred):
        """Save metrics for a specific level to database"""
        import sqlite3

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        # Insert training run
        cursor.execute('''
            INSERT INTO training_runs (level, accuracy, f1_weighted, train_size, test_size)
            VALUES (?, ?, ?, ?, ?)
        ''', (level, accuracy, f1_weighted, train_size, test_size))

        run_id = cursor.lastrowid

        # Get classification report
        report = classification_report(y_true, y_pred, output_dict=True, zero_division=0)

        # Save overall metrics
        cursor.execute('''
            INSERT INTO metrics (run_id, task, metric, value)
            VALUES (?, ?, ?, ?)
        ''', (run_id, level, 'accuracy_overall', accuracy))

        cursor.execute('''
            INSERT INTO metrics (run_id, task, metric, value)
            VALUES (?, ?, ?, ?)
        ''', (run_id, level, 'weighted_avg_f1_score', f1_weighted))

        # Save per-class metrics
        for class_name, metrics in report.items():
            if class_name in ['accuracy', 'macro avg', 'weighted avg']:
                continue

            if isinstance(metrics, dict):
                for metric_name, value in metrics.items():
                    if metric_name != 'support':
                        cursor.execute('''
                            INSERT INTO metrics (run_id, task, metric, value)
                            VALUES (?, ?, ?, ?)
                        ''', (run_id, level, f"{class_name}_{metric_name}", value))

        conn.commit()
        conn.close()

        self.logger.info(f"✓ Metrics saved to database (run_id: {run_id})")

    def save_metrics_to_sqlite(self, class_accuracy, class_f1_weighted, sent_accuracy, sent_f1_weighted, train_size,
                               test_size):
        """Legacy method for backwards compatibility - not used in 3-level system"""
        pass

    def save_full_classification_report_to_sqlite(self, run_id, task, y_true, y_pred):
        """Legacy method for backwards compatibility - not used in 3-level system"""
        pass

    def get_latest_metrics_from_db(self):
        """Retrieve latest metrics from all levels"""
        import sqlite3

        try:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()

            # Get latest run for each level
            cursor.execute('''
                SELECT run_id, level, accuracy, f1_weighted, timestamp
                FROM training_runs
                ORDER BY timestamp DESC
                LIMIT 10
            ''')

            runs = cursor.fetchall()

            if not runs:
                return {"error": "No training runs found"}

            # Get all metrics for latest runs
            cursor.execute('''
                SELECT m.task, m.metric, m.value
                FROM metrics m
                JOIN training_runs r ON m.run_id = r.run_id
                WHERE r.run_id IN (
                    SELECT run_id FROM training_runs
                    ORDER BY timestamp DESC
                    LIMIT 3
                )
                ORDER BY m.task, m.metric
            ''')

            metrics_rows = cursor.fetchall()

            conn.close()

            return {
                "metrics": [
                    {"task": row[0], "metric": row[1], "value": row[2]}
                    for row in metrics_rows
                ]
            }

        except Exception as e:
            self.logger.error(f"✗ Error retrieving metrics: {e}")
            return {"error": str(e)}

    def fit(self, event, data, tasks, **kwargs):
        """
        Train all 3 levels sequentially
        
        Training Flow:
        1. Level 1: Email → MasterDepartment
        2. Level 2: Email + MasterDepartment(actual) → Department
        3. Level 3: Email + MasterDepartment(actual) + Department(actual) → QueryType
        """
        
        # CRITICAL FIX: Only allow training on explicit webhook events
        # START_TRAINING = User clicked "Train" button in Label Studio ✅
        # Other events = Auto-training on startup ❌
        allowed_events = ['START_TRAINING', 'ANNOTATION_CREATED', 'ANNOTATION_UPDATED', 'ANNOTATIONS_CREATED']
        
        if event not in allowed_events:
            self.logger.info(f"⏸ Training skipped - event '{event}' not in allowed list. To train, click 'Train' button in Label Studio.")
            return
        
        self.logger.info("=" * 80)
        self.logger.info("🏗 3-LEVEL HIERARCHICAL TRAINING PIPELINE")
        self.logger.info(f"📊 Total tasks: {len(tasks)}")
        self.logger.info(f"🎯 Event: {event}")
        self.logger.info("=" * 80)

        # Train/test split (80/20)
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import LabelEncoder

        # Use local baseline if exists, otherwise fallback to HuggingFace
        baseline_model_dir = self.model_dir / "baseline-model"
        if os.path.exists(baseline_model_dir) and os.path.exists(baseline_model_dir / "config.json"):
            baseline_model = str(baseline_model_dir)
        else:
            baseline_model = self.config.get('BASELINE_MODEL_NAME', 'bert-base-uncased')

        # ========== LEVEL 1: MasterDepartment ==========
        self.logger.info("\n" + "=" * 80)
        self.logger.info("📍 LEVEL 1: EMAIL → MASTERDEPARTMENT")
        self.logger.info("=" * 80)

        masterdept_texts, masterdept_labels = self._prepare_dataset_for_level(tasks, "masterdepartment")

        if len(masterdept_texts) > 0:
            train_texts_md, test_texts_md, train_labels_md, test_labels_md = train_test_split(
                masterdept_texts, masterdept_labels, test_size=0.2, random_state=42
            )

            # FIX: Create and fit encoder on actual labels
            masterdept_encoder = LabelEncoder()
            all_masterdept_labels = train_labels_md + test_labels_md
            masterdept_encoder.fit(all_masterdept_labels)
            self.logger.info(f"✓ Fitted MasterDept encoder with {len(masterdept_encoder.classes_)} classes: {masterdept_encoder.classes_}")

            # Initialize model if needed
            num_masterdept_labels = len(masterdept_encoder.classes_)
            self.masterdept_model = SingleLevelModel(baseline_model, num_masterdept_labels, "masterdepartment")

            # Train
            self._train_single_level(
                train_texts_md, train_labels_md, test_texts_md, test_labels_md,
                "masterdepartment", self.masterdept_model, masterdept_encoder
            )
        else:
            self.logger.warning("⚠ No data for MasterDepartment training - skipping")

        # ========== LEVEL 2: Department ==========
        self.logger.info("\n" + "=" * 80)
        self.logger.info("📍 LEVEL 2: EMAIL + MASTERDEPARTMENT → DEPARTMENT")
        self.logger.info("=" * 80)

        dept_texts, dept_labels = self._prepare_dataset_for_level(tasks, "department")

        if len(dept_texts) > 0:
            train_texts_dept, test_texts_dept, train_labels_dept, test_labels_dept = train_test_split(
                dept_texts, dept_labels, test_size=0.2, random_state=42
            )

            # FIX: Create and fit encoder on actual labels
            dept_encoder = LabelEncoder()
            all_dept_labels = train_labels_dept + test_labels_dept
            dept_encoder.fit(all_dept_labels)
            self.logger.info(f"✓ Fitted Department encoder with {len(dept_encoder.classes_)} classes: {dept_encoder.classes_}")

            # Initialize model if needed
            num_dept_labels = len(dept_encoder.classes_)
            self.dept_model = SingleLevelModel(baseline_model, num_dept_labels, "department")

            # Train
            self._train_single_level(
                train_texts_dept, train_labels_dept, test_texts_dept, test_labels_dept,
                "department", self.dept_model, dept_encoder
            )
        else:
            self.logger.warning("⚠ No data for Department training - skipping")

        # ========== LEVEL 3: QueryType ==========
        self.logger.info("\n" + "=" * 80)
        self.logger.info("📍 LEVEL 3: EMAIL + MASTERDEPARTMENT + DEPARTMENT → QUERYTYPE")
        self.logger.info("=" * 80)

        querytype_texts, querytype_labels = self._prepare_dataset_for_level(tasks, "querytype")

        if len(querytype_texts) > 0:
            train_texts_qt, test_texts_qt, train_labels_qt, test_labels_qt = train_test_split(
                querytype_texts, querytype_labels, test_size=0.2, random_state=42
            )

            # FIX: Create and fit encoder on actual labels
            querytype_encoder = LabelEncoder()
            all_querytype_labels = train_labels_qt + test_labels_qt
            querytype_encoder.fit(all_querytype_labels)
            self.logger.info(f"✓ Fitted QueryType encoder with {len(querytype_encoder.classes_)} classes: {querytype_encoder.classes_}")

            # Initialize model if needed
            num_querytype_labels = len(querytype_encoder.classes_)
            self.querytype_model = SingleLevelModel(baseline_model, num_querytype_labels, "querytype")

            # Train
            self._train_single_level(
                train_texts_qt, train_labels_qt, test_texts_qt, test_labels_qt,
                "querytype", self.querytype_model, querytype_encoder
            )
        else:
            self.logger.warning("⚠ No data for QueryType training - skipping")

        self.logger.info("\n" + "=" * 80)
        self.logger.info("✅ ALL 3 LEVELS TRAINING COMPLETE!")
        self.logger.info("=" * 80)

        # ========== END-TO-END CASCADED EVALUATION ==========
        self.logger.info("\n" + "=" * 80)
        self.logger.info("🔬 END-TO-END CASCADED EVALUATION")
        self.logger.info("=" * 80)

        # Prepare full hierarchy test data (only if all 3 levels trained)
        if self.masterdept_model and self.dept_model and self.querytype_model:
            self.logger.info("Running full pipeline evaluation on test data...")
            
            # Get test samples with full hierarchies
            test_samples = []
            for task in tasks:
                try:
                    if not task.get('annotations'):
                        continue
                    
                    # Get email text
                    email_text = None
                    data = task.get('data', {})
                    if 'html' in data:
                        email_text = self.preload_task_data(task, data['html'])
                    elif 'text' in data:
                        email_text = data['text']
                    elif 'email' in data:
                        email_text = data['email']
                    
                    if not email_text:
                        continue
                    
                    # Get ground truth hierarchy
                    annotations_list = task['annotations']
                    if not isinstance(annotations_list, list):
                        annotations_list = [annotations_list]
                    
                    annotation = None
                    for ann in annotations_list:
                        if ann.get('was_cancelled') is False or 'result' in ann:
                            annotation = ann
                            break
                    
                    if not annotation:
                        continue
                    
                    annotation_results = annotation.get('result', [])
                    
                    # Extract classification path
                    classification_path = None
                    for item in annotation_results:
                        if item.get('type') != 'taxonomy':
                            continue
                        from_name = item.get('from_name', '').lower()
                        if 'classification' in from_name or 'query' in from_name or 'category' in from_name:
                            value = item.get('value', {})
                            taxonomy_data = value.get('taxonomy', [])
                            if isinstance(taxonomy_data, list) and len(taxonomy_data) > 0:
                                if isinstance(taxonomy_data[0], list) and len(taxonomy_data[0]) > 0:
                                    classification_path = taxonomy_data[0][0]
                                else:
                                    classification_path = taxonomy_data[0]
                            break
                    
                    if classification_path:
                        test_samples.append({
                            'email': email_text,
                            'ground_truth': classification_path
                        })
                
                except Exception as e:
                    self.logger.warning(f"Error processing task for evaluation: {e}")
                    continue
            
            if len(test_samples) > 0:
                self.logger.info(f"Evaluating on {len(test_samples)} test samples...")
                
                # Run cascaded prediction on each sample
                correct = 0
                total = len(test_samples)
                predictions_list = []
                ground_truths = []
                
                device = self._get_device()
                self.masterdept_model.to(device)
                self.masterdept_model.eval()
                self.dept_model.to(device)
                self.dept_model.eval()
                self.querytype_model.to(device)
                self.querytype_model.eval()
                
                for sample in test_samples:
                    email_text = sample['email']
                    ground_truth = sample['ground_truth']
                    
                    # Level 1 prediction
                    inputs, masks = self._tokenize_and_pad([email_text], self.tokenizer, 256)
                    inputs, masks = inputs.to(device), masks.to(device)
                    
                    with torch.no_grad():
                        logits = self.masterdept_model(inputs, masks)
                        pred_idx = torch.argmax(logits, dim=1).item()
                        masterdept_pred = self._decode_predictions([pred_idx], "masterdepartment")[0]
                    
                    # Level 2 prediction
                    conditional_text = f"MasterDepartment: {masterdept_pred} Email: {email_text}"
                    inputs, masks = self._tokenize_and_pad([conditional_text], self.tokenizer, 256)
                    inputs, masks = inputs.to(device), masks.to(device)
                    
                    with torch.no_grad():
                        logits = self.dept_model(inputs, masks)
                        pred_idx = torch.argmax(logits, dim=1).item()
                        dept_pred = self._decode_predictions([pred_idx], "department")[0]
                    
                    # Level 3 prediction
                    conditional_text = f"MasterDepartment: {masterdept_pred} Department: {dept_pred} Email: {email_text}"
                    inputs, masks = self._tokenize_and_pad([conditional_text], self.tokenizer, 256)
                    inputs, masks = inputs.to(device), masks.to(device)
                    
                    with torch.no_grad():
                        logits = self.querytype_model(inputs, masks)
                        pred_idx = torch.argmax(logits, dim=1).item()
                        querytype_pred = self._decode_predictions([pred_idx], "querytype")[0]
                    
                    # Build combined prediction
                    combined_pred = f"{masterdept_pred} > {dept_pred} > {querytype_pred}"
                    
                    predictions_list.append(combined_pred)
                    ground_truths.append(ground_truth)
                    
                    if combined_pred == ground_truth:
                        correct += 1
                
                # Calculate end-to-end accuracy
                e2e_accuracy = correct / total if total > 0 else 0
                
                self.logger.info(f"✓ End-to-End Accuracy: {e2e_accuracy:.4f} ({correct}/{total})")
                
                # Calculate per-class metrics for combined hierarchies
                from sklearn.metrics import classification_report
                
                try:
                    report = classification_report(ground_truths, predictions_list, output_dict=True, zero_division=0)
                    
                    # Save end-to-end metrics to database
                    import sqlite3
                    conn = sqlite3.connect(str(self.db_path))
                    cursor = conn.cursor()
                    
                    # Save overall end-to-end run
                    cursor.execute('''
                        INSERT INTO training_runs (level, accuracy, f1_weighted, train_size, test_size)
                        VALUES (?, ?, ?, ?, ?)
                    ''', ('end_to_end', e2e_accuracy, report.get('weighted avg', {}).get('f1-score', 0), 0, total))
                    
                    run_id = cursor.lastrowid
                    
                    # Save per-class metrics for each unique hierarchy
                    for class_name, metrics in report.items():
                        if class_name in ['accuracy', 'macro avg', 'weighted avg']:
                            continue
                        if isinstance(metrics, dict):
                            for metric_name, value in metrics.items():
                                cursor.execute('''
                                    INSERT INTO metrics (run_id, task, metric, value)
                                    VALUES (?, ?, ?, ?)
                                ''', (run_id, 'end_to_end', f"{class_name}_{metric_name}", value))
                    
                    conn.commit()
                    conn.close()
                    
                    self.logger.info(f"✓ End-to-end metrics saved to database")
                    
                except Exception as e:
                    self.logger.error(f"Error saving end-to-end metrics: {e}")
            
            else:
                self.logger.warning("No test samples available for end-to-end evaluation")
        else:
            self.logger.warning("Skipping end-to-end evaluation - not all 3 models trained")

    def predict(self, tasks: List[Dict], texts: str, context: Optional[Dict] = None, **kwargs):
        """
        3-LEVEL CASCADING INFERENCE

        Level 1: Email → MasterDepartment(predicted)
        Level 2: Email + MasterDepartment(predicted) → Department(predicted)
        Level 3: Email + MasterDepartment(predicted) + Department(predicted) → QueryType(predicted)

        Returns all predictions in a single result.
        """

        self.logger.info(f"🔮 Running 3-level inference on {len(texts)} email(s)...")

        # Get taxonomy field names from label interface
        def getMasterDeptAttrName(attrs):
            return attrs == "masterdepartment"

        def getDeptAttrName(attrs):
            return attrs == "department"

        def getQueryTypeAttrName(attrs):
            return attrs == "querytype"

        from_name_masterdept, to_name_masterdept, _ = \
            self.label_interface.get_first_tag_occurence(
                "Taxonomy", "HyperText", getMasterDeptAttrName
            )

        from_name_dept, to_name_dept, _ = \
            self.label_interface.get_first_tag_occurence(
                "Taxonomy", "HyperText", getDeptAttrName
            )

        from_name_querytype, to_name_querytype, _ = \
            self.label_interface.get_first_tag_occurence(
                "Taxonomy", "HyperText", getQueryTypeAttrName
            )

        tokenizer = self.tokenizer

        # Extract text from dict or use string directly
        text_list = [
            text['text'] if not isinstance(text, str) else text
            for text in texts
        ]

        MAX_LEN = 256
        batch_size = 16

        device = self._get_device()

        # Prepare models
        if self.masterdept_model:
            self.masterdept_model.to(device)
            self.masterdept_model.eval()

        if self.dept_model:
            self.dept_model.to(device)
            self.dept_model.eval()

        if self.querytype_model:
            self.querytype_model.to(device)
            self.querytype_model.eval()

        predictions = []

        # Process each email
        for text in text_list:
            email_text = text

            # ========== LEVEL 1: Email → MasterDepartment ==========
            masterdept_pred = None
            masterdept_score = 0.0

            if self.masterdept_model:
                inputs, masks = self._tokenize_and_pad([email_text], tokenizer, MAX_LEN)
                inputs, masks = inputs.to(device), masks.to(device)

                with torch.no_grad():
                    logits = self.masterdept_model(inputs, masks)
                    probs = torch.softmax(logits, dim=1)
                    pred_idx = torch.argmax(probs, dim=1).item()
                    masterdept_score = probs[0][pred_idx].item()

                    # Decode prediction
                    masterdept_pred = self._decode_predictions([pred_idx], "masterdepartment")[0]

                self.logger.info(f"  Level 1: {masterdept_pred} (score: {masterdept_score:.4f})")

            # ========== LEVEL 2: Email + MasterDepartment(PREDICTED) → Department ==========
            dept_pred = None
            dept_score = 0.0

            if self.dept_model and masterdept_pred:
                # CRITICAL: Use PREDICTED MasterDepartment, not actual
                conditional_text_dept = f"MasterDepartment: {masterdept_pred} Email: {email_text}"

                inputs, masks = self._tokenize_and_pad([conditional_text_dept], tokenizer, MAX_LEN)
                inputs, masks = inputs.to(device), masks.to(device)

                with torch.no_grad():
                    logits = self.dept_model(inputs, masks)
                    probs = torch.softmax(logits, dim=1)
                    pred_idx = torch.argmax(probs, dim=1).item()
                    dept_score = probs[0][pred_idx].item()

                    # Decode prediction
                    dept_pred = self._decode_predictions([pred_idx], "department")[0]

                self.logger.info(f"  Level 2: {dept_pred} (score: {dept_score:.4f})")

            # ========== LEVEL 3: Email + MasterDepartment(PREDICTED) + Department(PREDICTED) → QueryType ==========
            querytype_pred = None
            querytype_score = 0.0

            if self.querytype_model and masterdept_pred and dept_pred:
                # CRITICAL: Use PREDICTED MasterDepartment and Department, not actual
                conditional_text_qt = f"MasterDepartment: {masterdept_pred} Department: {dept_pred} Email: {email_text}"

                inputs, masks = self._tokenize_and_pad([conditional_text_qt], tokenizer, MAX_LEN)
                inputs, masks = inputs.to(device), masks.to(device)

                with torch.no_grad():
                    logits = self.querytype_model(inputs, masks)
                    probs = torch.softmax(logits, dim=1)
                    pred_idx = torch.argmax(probs, dim=1).item()
                    querytype_score = probs[0][pred_idx].item()

                    # Decode prediction
                    querytype_pred = self._decode_predictions([pred_idx], "querytype")[0]

                self.logger.info(f"  Level 3: {querytype_pred} (score: {querytype_score:.4f})")

            # ========== BUILD SINGLE HIERARCHICAL PREDICTION ==========
            # Combine all 3 levels into ONE taxonomy path: "MasterDept > Dept > QueryType"
            hierarchical_path_parts = []
            if masterdept_pred:
                hierarchical_path_parts.append(masterdept_pred)
            if dept_pred:
                hierarchical_path_parts.append(dept_pred)
            if querytype_pred:
                hierarchical_path_parts.append(querytype_pred)

            # Join with " > " separator
            combined_path = " > ".join(hierarchical_path_parts)
            
            # Calculate average confidence score
            scores = [s for s in [masterdept_score, dept_score, querytype_score] if s > 0]
            avg_score = sum(scores) / len(scores) if scores else 0.0

            # Return SINGLE combined prediction (not 3 separate ones)
            predictions.append({
                "from_name": "classification",  # Use your actual classification field name
                "to_name": to_name_masterdept,  # Use same to_name
                "type": "taxonomy",
                "value": {
                    "taxonomy": [[combined_path]],  # SINGLE hierarchical path
                    "score": avg_score
                }
            })

            self.logger.info(f"  ✓ Combined Hierarchy: {combined_path} (avg score: {avg_score:.4f})")

        self.logger.info(f"✓ 3-level inference complete - Generated {len(predictions)} combined predictions")
        return predictions

    def fit_external(self, event, data, tasks, **kwargs):
        """External training wrapper"""
        self.logger.info("🎯 External training initiated")
        return self.fit(event, data, tasks, **kwargs)