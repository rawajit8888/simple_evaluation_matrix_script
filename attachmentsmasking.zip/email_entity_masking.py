import sys
import re
import json
import argparse
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModelForTokenClassification, pipeline
from presidio_analyzer import Pattern, PatternRecognizer, AnalyzerEngine, RecognizerRegistry, EntityRecognizer, RecognizerResult
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig

# =========================
# GPU setup
# =========================
device = 0 if torch.cuda.is_available() else -1
# print(f"Using device: {'GPU' if device >= 0 else 'CPU'}")
# print(f"Using device: {'GPU' if device >= 0 else 'CPU'}", file=sys.stderr)

# =========================
# Load IndicNER
# =========================
model_name = r"C:\Bombus\Actionabl_dev\Work\piiMasking\indi_ner_model"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForTokenClassification.from_pretrained(model_name)
ner_pipeline = pipeline(
    "ner",
    model=model,
    tokenizer=tokenizer,
    aggregation_strategy="simple",
    device=device
)

# =========================
# Custom Recognizer for IndicNER
# =========================
class IndicNERRecognizer(EntityRecognizer):
    def __init__(self, ner_pipeline, supported_entities=None, name="IndicNERRecognizer"):
        self.ner_pipeline = ner_pipeline
        supported_entities = supported_entities or ["PERSON"]
        super().__init__(supported_entities=supported_entities, name=name)

    def analyze(self, text, entities, nlp_artifacts=None):
        results = []
        predictions = self.ner_pipeline(text)
        for p in predictions:
            if p["entity_group"] == "PER" and "PERSON" in entities:
                results.append(
                    RecognizerResult(
                        entity_type="PERSON",
                        start=p["start"],
                        end=p["end"],
                        score=p["score"]
                    )
                )
        return results

# =========================
# Load regex patterns from config.json
# =========================
with open("config.json", "r") as f:
    config = json.load(f)

registry = RecognizerRegistry()
registry.load_predefined_recognizers()

for item in config["patterns"]:
    name = item["name"]
    regex = item["regex"]
    pattern = Pattern(name=f"{name} pattern", regex=regex, score=0.9)
    recognizer = PatternRecognizer(supported_entity=name, patterns=[pattern])
    registry.add_recognizer(recognizer)

# Add custom IndicNER
registry.add_recognizer(IndicNERRecognizer(ner_pipeline))

analyzer = AnalyzerEngine(registry=registry)
anonymizer = AnonymizerEngine()

# =========================
# Helper functions
# =========================
def partial_mask(value, unmasked_digits=4):
    value = value.strip()
    if len(value) <= unmasked_digits:
        return "X" * len(value)
    return "X" * (len(value) - unmasked_digits) + value[-unmasked_digits:]

# =========================
# Mask text with [NAME 1], [NAME 2], [EMAIL 1], etc.
# =========================
def mask_text_and_build_map(text):
    results = analyzer.analyze(
        text=text,
        entities=[
            "DP_ACCOUNT", "DP_ID", "TRADING_ID", "PAN",
            "DP_ACCOUNT_CDSL", "BANK_ACC", "PERSON",
            "EMAIL_ADDRESS", "PHONE_NUMBER", "AADHAR"
        ],
        language='en'
    )

    if not results:
        return text, {}

    results = sorted(results, key=lambda x: x.start)

    entity_map = {}
    masked_parts = []
    last_idx = 0
    email_counter = 1

    for r in results:
        start, end = r.start, r.end
        original = text[start:end]

        # Add text before current entity
        masked_parts.append(text[last_idx:start])

        # ===== PERSON masking with numbering logic and strict boundary expansion =====
        if r.entity_type == "PERSON":
            s = start
            while s > 0 and text[s-1].isalpha() and text[s-1] not in ['\n', '\r', ':']:
                s -= 1
            e = end
            while e < len(text) and text[e].isalpha() and text[e] not in ['\n', '\r', ':']:
                e += 1

            full_name = text[s:e].strip()

            # Avoid capturing across newlines
            if "\n" in full_name:
                full_name = original.strip()

            # Create numbered tag for each unique name
            name_tag = f"[NAME {len([k for k in entity_map.keys() if k.startswith('[NAME')]) + 1}]"
            masked_parts[-1] = text[last_idx:s]
            masked_parts.append(name_tag)
            entity_map.setdefault(name_tag, []).append(full_name)
            last_idx = e
            continue

        # ===== EMAIL masking =====
        elif r.entity_type == "EMAIL_ADDRESS":
            tag = f"[EMAIL {email_counter}]"
            entity_map.setdefault(tag, []).append(original.strip())
            masked_parts.append(tag)
            email_counter += 1

        # ===== Numeric / ID fields =====
        elif r.entity_type in [
            "DP_ACCOUNT", "DP_ID", "BANK_ACC", "PHONE_NUMBER",
            "TRADING_ID", "DP_ACCOUNT_CDSL", "AADHAR","IFSC"
        ]:
            masked_value = partial_mask(original)
            entity_map.setdefault(masked_value, []).append(original.strip())
            masked_parts.append(masked_value)

        # ===== Fallback =====
        else:
            tag = f"<{r.entity_type}>"
            entity_map.setdefault(tag, []).append(original.strip())
            masked_parts.append(tag)

        last_idx = end

    # Append trailing text
    masked_parts.append(text[last_idx:])
    masked_text = ''.join(masked_parts)

    return masked_text, entity_map

# =========================
# Unmask text
# =========================
def unmask_text(masked_text, entity_map):
    unmasked = masked_text
    for tag, values in entity_map.items():
        for val in values:
            if tag in ["<DP_ACCOUNT>", "<DP_ID>", "<BANK_ACC>", "<PHONE_NUMBER>", "<TRADING_ID>", "<AADHAR>"]:
                pattern = re.escape(partial_mask(val))
            elif tag.startswith("[NAME"):
                pattern = re.escape(tag)
            else:
                pattern = re.escape(tag)
            unmasked = re.sub(pattern, val, unmasked, count=1)
    return unmasked

# =========================
# Main Excel input/output
# =========================

# Read input text (email body) from stdin
text = sys.stdin.read()

# Mask the input text
masked, entity_map = mask_text_and_build_map(text)

# print("masked email : ",masked)

# Output masked text and entity map as JSON string
print(json.dumps({
    "masked": masked,
    "entity_map": entity_map
}, ensure_ascii=False), flush=True)

