#!/usr/bin/env python
"""
Setup Validation Script for 3-Level Hierarchical Email Classification
Run this before starting training to verify your configuration
"""

import os
import sys
from pathlib import Path

def print_status(message, status):
    """Print colored status message"""
    if status == "OK":
        print(f"✅ {message}")
    elif status == "WARNING":
        print(f"⚠️  {message}")
    else:
        print(f"❌ {message}")

def check_model_directory():
    """Check if model directory exists and is configured correctly"""
    model_dir = os.getenv('MODEL_DIR', './results/bert-classification-sentiment3level_training')
    
    print("\n" + "=" * 80)
    print("CHECKING MODEL DIRECTORY")
    print("=" * 80)
    
    if os.path.exists(model_dir):
        print_status(f"Model directory exists: {model_dir}", "OK")
    else:
        print_status(f"Model directory NOT found: {model_dir}", "ERROR")
        print(f"   Creating directory: {model_dir}")
        os.makedirs(model_dir, exist_ok=True)
        print_status(f"Directory created", "OK")
    
    return model_dir

def check_local_model(model_dir):
    """Check if local BERT model exists"""
    print("\n" + "=" * 80)
    print("CHECKING LOCAL BERT MODEL")
    print("=" * 80)
    
    local_model_path = os.path.join(model_dir, 'lsmb-base-model')
    
    if os.path.exists(local_model_path):
        print_status(f"Local model found: {local_model_path}", "OK")
        
        # Check for required files
        required_files = [
            'config.json',
            'pytorch_model.bin',
            'tokenizer_config.json',
            'vocab.txt'
        ]
        
        missing_files = []
        for file in required_files:
            file_path = os.path.join(local_model_path, file)
            if os.path.exists(file_path):
                print_status(f"  Found: {file}", "OK")
            else:
                missing_files.append(file)
                print_status(f"  Missing: {file}", "ERROR")
        
        if missing_files:
            print("\n⚠️  Some model files are missing. Download instructions:")
            print("""
from transformers import AutoTokenizer, AutoModel

model_name = "bert-base-uncased"
save_path = "{}"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

tokenizer.save_pretrained(save_path)
model.save_pretrained(save_path)
print("✓ Model downloaded and saved")
""".format(local_model_path))
            return False
        return True
    else:
        print_status(f"Local model NOT found: {local_model_path}", "WARNING")
        print("\n📥 Will use HuggingFace model 'bert-base-uncased' instead")
        print("   To use local model, download it to:", local_model_path)
        return True  # Not critical - will use HF model

def check_python_files():
    """Check if all required Python files exist"""
    print("\n" + "=" * 80)
    print("CHECKING PYTHON FILES")
    print("=" * 80)
    
    required_files = {
        'multi_task_model.py': 'Core training and inference logic',
        'multitask_nn_model.py': 'Level 1 model architecture',
        'model.py': 'Label Studio integration',
        '_wsgi.py': 'WSGI server configuration',
        'dataprocessing/processlabels.py': 'Label encoder management'
    }
    
    all_exist = True
    for file, description in required_files.items():
        if os.path.exists(file):
            print_status(f"{file} - {description}", "OK")
        else:
            print_status(f"{file} - {description}", "ERROR")
            all_exist = False
    
    return all_exist

def check_dependencies():
    """Check if required Python packages are installed"""
    print("\n" + "=" * 80)
    print("CHECKING PYTHON DEPENDENCIES")
    print("=" * 80)
    
    required_packages = [
        'torch',
        'transformers',
        'sklearn',
        'pandas',
        'numpy',
        'label_studio_sdk',
        'flask'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package)
            print_status(f"{package}", "OK")
        except ImportError:
            print_status(f"{package}", "ERROR")
            missing_packages.append(package)
    
    if missing_packages:
        print("\n❌ Missing packages. Install with:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    return True

def check_environment_variables():
    """Check if environment variables are set"""
    print("\n" + "=" * 80)
    print("CHECKING ENVIRONMENT VARIABLES")
    print("=" * 80)
    
    required_vars = {
        'MODEL_DIR': './results/bert-classification-sentiment3level_training',
        'LABEL_STUDIO_HOST': 'http://localhost:8080',
        'LABEL_STUDIO_API_KEY': 'your-api-key-here'
    }
    
    optional_vars = {
        'NUM_TRAIN_EPOCHS': '10',
        'LEARNING_RATE': '2e-5',
        'START_TRAINING_EACH_N_UPDATES': '10'
    }
    
    print("\nRequired variables:")
    for var, default in required_vars.items():
        value = os.getenv(var, default)
        if value == default and var == 'LABEL_STUDIO_API_KEY':
            print_status(f"{var} = {value} (default - UPDATE THIS!)", "WARNING")
        else:
            print_status(f"{var} = {value}", "OK")
    
    print("\nOptional variables (using defaults if not set):")
    for var, default in optional_vars.items():
        value = os.getenv(var, default)
        print_status(f"{var} = {value}", "OK")
    
    return True

def check_directory_structure(model_dir):
    """Check and create necessary directories"""
    print("\n" + "=" * 80)
    print("CHECKING DIRECTORY STRUCTURE")
    print("=" * 80)
    
    required_dirs = [
        'encoders',
    ]
    
    for dir_name in required_dirs:
        dir_path = os.path.join(model_dir, dir_name)
        if os.path.exists(dir_path):
            print_status(f"{dir_name}/", "OK")
        else:
            print_status(f"{dir_name}/ (creating...)", "WARNING")
            os.makedirs(dir_path, exist_ok=True)
            print_status(f"{dir_name}/ created", "OK")
    
    return True

def main():
    """Run all validation checks"""
    print("\n" + "=" * 80)
    print("3-LEVEL HIERARCHICAL EMAIL CLASSIFICATION - SETUP VALIDATOR")
    print("=" * 80)
    
    checks = []
    
    # Check 1: Model directory
    model_dir = check_model_directory()
    checks.append(("Model Directory", True))
    
    # Check 2: Local BERT model
    model_ok = check_local_model(model_dir)
    checks.append(("Local BERT Model", model_ok))
    
    # Check 3: Python files
    files_ok = check_python_files()
    checks.append(("Python Files", files_ok))
    
    # Check 4: Dependencies
    deps_ok = check_dependencies()
    checks.append(("Dependencies", deps_ok))
    
    # Check 5: Environment variables
    env_ok = check_environment_variables()
    checks.append(("Environment Variables", env_ok))
    
    # Check 6: Directory structure
    dirs_ok = check_directory_structure(model_dir)
    checks.append(("Directory Structure", dirs_ok))
    
    # Summary
    print("\n" + "=" * 80)
    print("VALIDATION SUMMARY")
    print("=" * 80)
    
    all_passed = all(check[1] for check in checks)
    
    for check_name, passed in checks:
        if passed:
            print_status(f"{check_name}", "OK")
        else:
            print_status(f"{check_name}", "ERROR")
    
    print("\n" + "=" * 80)
    if all_passed:
        print("✅ ALL CHECKS PASSED - Ready to start training!")
        print("=" * 80)
        print("\nNext steps:")
        print("1. Start ML backend: python _wsgi.py --port 9090")
        print("2. Connect Label Studio to http://localhost:9090")
        print("3. Label at least 50 tasks with all fields")
        print("4. Click 'Start Training' in Label Studio")
        return 0
    else:
        print("❌ SOME CHECKS FAILED - Please fix the issues above")
        print("=" * 80)
        return 1

if __name__ == "__main__":
    sys.exit(main())
